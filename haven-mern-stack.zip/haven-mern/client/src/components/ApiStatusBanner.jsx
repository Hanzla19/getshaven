import { useEffect, useState } from 'react';
import { checkHealth } from '../api/health';

/**
 * On mount, pings the real backend's /api/health route. If it's unreachable
 * (server not running, wrong VITE_API_URL, CORS misconfigured, etc.), shows
 * one clear, actionable banner instead of leaving the person to piece
 * together several silent failures (empty map, "could not reach the API" in
 * chat, empty listings) on their own.
 */
export default function ApiStatusBanner() {
  const [status, setStatus] = useState('checking'); // 'checking' | 'ok' | 'down'
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    checkHealth()
      .then(() => setStatus('ok'))
      .catch(() => setStatus('down'));
  }, []);

  if (status !== 'down' || dismissed) return null;

  const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 2000,
      background: '#3A1616', color: '#fff', padding: '12px 20px',
      fontSize: 13.5, display: 'flex', alignItems: 'center', justifyContent: 'center',
      gap: 16, flexWrap: 'wrap', textAlign: 'center'
    }}>
      <span>
        <b>Backend not reachable</b> at <code>{apiUrl}</code>. Properties, the AI finder, the map, and saved
        items won't work until it's running. In the project root: <code>cd server</code> → confirm{' '}
        <code>.env</code> exists with a valid <code>MONGO_URI</code> → <code>npm run dev</code> →
        (first time only) <code>npm run seed</code>.
      </span>
      <button
        onClick={() => setDismissed(true)}
        style={{ background: 'rgba(255,255,255,.15)', color: '#fff', borderRadius: 100, padding: '4px 12px', fontSize: 12, flexShrink: 0 }}
      >
        Dismiss
      </button>
    </div>
  );
}
