import { useApp } from '../context/AppContext';
import { fmtMoney } from '../utils/format';
import { directionsUrl } from '../utils/directions';
import MediaStack from './MediaStack';

export default function PropertyModal({ property, match, requirements, onClose, onOpenTour }) {
  const { currency, savedIds, toggleSaved, toggleCompare } = useApp();
  if (!property) return null;
  const p = property;
  const m = p.media || {};
  const isSaved = savedIds.has(p._id);

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-card">
        <button className="modal-close" onClick={onClose} aria-label="Close">✕</button>
        <div style={{ aspectRatio: '16/8', overflow: 'hidden', position: 'relative' }}>
          <MediaStack
            svgKey={m.svgArtKey || 'house'} label={p.title} seed={p._id}
            photoUrl={m.photoUrl} video={m.videoUrl ? { src: m.videoUrl, poster: m.videoPoster } : null} alt={p.title}
          />
        </div>
        <div style={{ padding: 32 }}>
          <span style={{ fontSize: 11, fontWeight: 700, background: 'var(--stone)', padding: '5px 10px', borderRadius: 6 }}>Illustrative example</span>
          <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 28, margin: '14px 0 4px' }}>{p.title}</h2>
          <p style={{ color: 'var(--ink-soft)', marginBottom: 16 }}>{p.neighborhood}, {p.city}, {p.country}</p>
          <div style={{ display: 'flex', gap: 26, flexWrap: 'wrap', marginBottom: 18 }}>
            <div className="p-price" style={{ fontSize: 26 }}>{fmtMoney(p.priceUSD, currency)}{p.purpose === 'rent' && <span> / month</span>}</div>
            <div className="p-specs" style={{ border: 'none', padding: 0 }}>
              <span><b>{p.beds}</b> bed</span><span><b>{p.baths}</b> bath</span><span><b>{p.sizeSqft?.toLocaleString()}</b> sqft</span>
            </div>
          </div>
          <p style={{ fontSize: 14.5, color: 'var(--ink-soft)', lineHeight: 1.65 }}>{p.description}</p>

          {p.source && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 14, fontSize: 12.5, color: 'var(--ink-soft)', background: 'var(--stone)', borderRadius: 8, padding: '10px 14px', flexWrap: 'wrap' }}>
              <span>This is a mock listing, but the price reflects real market data for {p.neighborhood}:</span>
              <a href={p.source.url} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--teal)', fontWeight: 600 }}>{p.source.label} ↗</a>
            </div>
          )}

          {match && (
            <div className="match-box">
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14 }}>
                <div className="match-score-num">{match.score}%</div>
                <div>
                  <b style={{ fontSize: 14.5 }}>AI match score</b>
                  <div style={{ fontSize: 12.5, color: 'var(--ink-soft)' }}>Based on your stated preferences — an estimate, not a guarantee.</div>
                </div>
              </div>
              {Object.entries(match.breakdown).map(([k, v]) => (
                <div className="score-row" key={k}>
                  <span className="score-label">{k}</span>
                  <div className="score-track"><div className="score-fill" style={{ width: `${v}%` }} /></div>
                  <span className="score-val">{v}%</span>
                </div>
              ))}
              {match.explanation && (
                <>
                  <p style={{ fontSize: 13.5, marginTop: 14, color: 'var(--ink-soft)' }}><b style={{ color: 'var(--ink)' }}>Why this home:</b> {match.explanation.why}</p>
                  <p style={{ fontSize: 13.5, marginTop: 8, color: 'var(--ink-soft)' }}><b style={{ color: 'var(--ink)' }}>Potential concerns:</b> {match.explanation.concern}</p>
                </>
              )}
            </div>
          )}

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 22 }}>
            <button className="btn btn-gold" onClick={() => { onClose(); onOpenTour(p); }}>Enter 3D Tour</button>
            <a href={directionsUrl(p.lat, p.lng, `${p.title}, ${p.neighborhood}, ${p.city}`)} target="_blank" rel="noopener noreferrer" className="btn btn-outline">
              Get Directions
            </a>
            <button className="btn btn-outline" onClick={() => toggleSaved(p._id)}>{isSaved ? 'Saved ✓' : 'Save property'}</button>
            <button className="btn btn-outline" onClick={() => { toggleCompare(p._id); onClose(); }}>Add to comparison</button>
          </div>
        </div>
      </div>
    </div>
  );
}
