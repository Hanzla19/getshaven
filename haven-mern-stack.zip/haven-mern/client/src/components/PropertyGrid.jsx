import { useEffect, useState, useCallback } from 'react';
import { fetchProperties } from '../api/properties';
import PropertyCard from './PropertyCard';
import { useApp } from '../context/AppContext';

/**
 * Renders either:
 *  - AI-matched results (when `matches` is provided by AIFinder), or
 *  - a plain filtered list fetched fresh from the API.
 */
export default function PropertyGrid({ matches, searchParams, onOpen }) {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('all');
  const { savedIds } = useApp();

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchProperties(searchParams || {});
      setProperties(data);
    } catch (err) {
      setError('Could not reach the API. Is the backend running (npm run dev in /server) and seeded (npm run seed)?');
    } finally {
      setLoading(false);
    }
  }, [searchParams]);

  useEffect(() => { if (!matches) load(); }, [load, matches]);

  const scoreMap = {};
  let list = matches ? matches.map(m => { scoreMap[m.property._id] = m.score; return m.property; }) : properties;

  if (filter === 'buy') list = list.filter(p => p.purpose === 'buy');
  if (filter === 'rent') list = list.filter(p => p.purpose === 'rent');
  if (filter === 'saved') list = list.filter(p => savedIds.has(p._id));

  return (
    <section className="wrap" id="listings">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 20, marginBottom: 36 }}>
        <div className="section-head" style={{ marginBottom: 0 }}>
          <span className="section-tag">{matches ? 'Personalized matches' : 'Browse properties'}</span>
          <h2>{matches ? 'Your AI-recommended matches' : 'Example properties from around the world'}</h2>
          <p>{matches ? 'Ranked by fit to what you told Haven. Scores are AI estimates, not guarantees.' : 'Illustrative listings, priced using real market research for each neighborhood.'}</p>
        </div>
        <div className="filter-row">
          {['all', 'buy', 'rent', 'saved'].map(f => (
            <button key={f} className={`filter-pill${filter === f ? ' active' : ''}`} onClick={() => setFilter(f)}>
              {f === 'all' ? 'All' : f === 'buy' ? 'For sale' : f === 'rent' ? 'For rent' : 'Saved'}
            </button>
          ))}
        </div>
      </div>

      {loading && <p style={{ color: 'var(--ink-soft)' }}>Loading properties…</p>}
      {error && <p style={{ color: '#B33' }}>{error}</p>}
      {!loading && !error && list.length === 0 && (
        <p style={{ color: 'var(--ink-soft)' }}>No properties match this filter yet. Try another filter, or ask the AI finder above.</p>
      )}

      <div className="grid-listings">
        {list.map(p => (
          <PropertyCard key={p._id} property={p} score={scoreMap[p._id]} onOpen={onOpen} />
        ))}
      </div>
    </section>
  );
}
