import { useState } from 'react';
import { generateSellerDraft } from '../api/ai';

export default function SellSection() {
  const [type, setType] = useState('House');
  const [beds, setBeds] = useState(3);
  const [features, setFeatures] = useState('');
  const [draft, setDraft] = useState(null);
  const [loading, setLoading] = useState(false);

  async function generate() {
    setLoading(true);
    try {
      const result = await generateSellerDraft({
        type, beds,
        features: features.split(',').map(s => s.trim()).filter(Boolean)
      });
      setDraft(result);
    } catch (err) {
      setDraft({ headline: 'Could not reach the AI service', description: 'Is the backend running (npm run dev in /server)?' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="wrap" id="sell">
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 50, alignItems: 'center' }} className="dual-grid">
        <div style={{ borderRadius: 'var(--radius-l)', overflow: 'hidden', aspectRatio: '4/3', position: 'relative' }}>
          <img
            src="https://images.pexels.com/videos/3773488/decoration-design-estate-furniture-3773488.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600"
            alt="Bright open-plan kitchen"
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          <div style={{ position: 'absolute', bottom: 18, left: 18, right: 18, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {['Bright open-plan layout', 'Large windows', 'AI-organized listing'].map(t => (
              <span key={t} style={{ background: 'rgba(255,255,255,.94)', padding: '7px 13px', borderRadius: 100, fontSize: 12.5, fontWeight: 600, color: 'var(--ink)' }}>{t}</span>
            ))}
          </div>
        </div>
        <div>
          <span className="section-tag">Sell with AI</span>
          <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 'clamp(26px,3.4vw,38px)', margin: '10px 0 14px' }}>
            Understand your property, reach the right buyers.
          </h2>
          <p style={{ color: 'var(--ink-soft)', marginBottom: 20 }}>
            Answer a few questions and Haven helps you draft a compelling, honest listing. AI only describes what's actually provided — it never invents features.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
            <div>
              <label style={{ fontSize: 12.5, fontWeight: 600, display: 'block', marginBottom: 6 }}>Property type</label>
              <select value={type} onChange={e => setType(e.target.value)} style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid var(--stone-dark)' }}>
                <option>House</option><option>Apartment</option><option>Villa</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: 12.5, fontWeight: 600, display: 'block', marginBottom: 6 }}>Bedrooms</label>
              <select value={beds} onChange={e => setBeds(Number(e.target.value))} style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid var(--stone-dark)' }}>
                <option value={1}>1</option><option value={3}>3</option><option value={4}>4</option><option value={5}>5+</option>
              </select>
            </div>
          </div>
          <label style={{ fontSize: 12.5, fontWeight: 600, display: 'block', marginBottom: 6 }}>Notable features (comma separated)</label>
          <input
            value={features} onChange={e => setFeatures(e.target.value)}
            placeholder="bright open-plan kitchen, large backyard, two-car garage"
            style={{ width: '100%', padding: 12, borderRadius: 8, border: '1px solid var(--stone-dark)', marginBottom: 16 }}
          />
          <button className="btn btn-teal" onClick={generate} disabled={loading}>{loading ? 'Generating…' : 'Generate listing draft'}</button>

          {draft && (
            <div style={{ background: 'var(--stone)', borderRadius: 'var(--radius-m)', padding: 20, marginTop: 18 }}>
              <b style={{ fontSize: 14 }}>Suggested headline</b>
              <p style={{ fontFamily: "'Fraunces',serif", fontSize: 18, margin: '6px 0 14px' }}>{draft.headline}</p>
              <b style={{ fontSize: 14 }}>Draft description</b>
              <p style={{ fontSize: 14, color: 'var(--ink-soft)', marginTop: 6, lineHeight: 1.6 }}>{draft.description}</p>
            </div>
          )}
          <p style={{ fontSize: 11.5, color: 'var(--ink-soft)', marginTop: 16, background: 'var(--stone)', padding: '12px 14px', borderRadius: 8, lineHeight: 1.6 }}>
            Any valuation shown elsewhere in Haven is an estimate, not a guaranteed market value.
          </p>
        </div>
      </div>
    </section>
  );
}
