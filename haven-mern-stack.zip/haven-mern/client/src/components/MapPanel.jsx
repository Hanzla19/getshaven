import { useEffect, useState } from 'react';
import { fetchProperties } from '../api/properties';
import { embedMapSrc, directionsUrl } from '../utils/directions';
import { fmtMoney } from '../utils/format';
import { useApp } from '../context/AppContext';

export default function MapPanel({ onOpen }) {
  const { currency } = useApp();
  const [properties, setProperties] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchProperties()
      .then(list => {
        setProperties(list);
        if (list.length) setSelectedId(list[0]._id);
      })
      .catch(() => setError('Could not load properties for the map. Is the backend running (npm run dev in /server) and seeded (npm run seed)?'));
  }, []);

  const selected = properties.find(p => p._id === selectedId);

  return (
    <section className="wrap" id="map">
      <div className="section-head">
        <span className="section-tag">Interactive map</span>
        <h2>See homes in context, not just in a list.</h2>
        <p>A real, live map centered on each property's actual coordinates — switch between listings, then get real turn-by-turn directions.</p>
      </div>
      <div className="map-layout">
        <div className="map-canvas">
          {error && (
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 30, textAlign: 'center' }}>
              <p style={{ color: 'var(--ink-soft)', fontSize: 14, maxWidth: 320 }}>{error}</p>
            </div>
          )}
          {selected && (
            <iframe
              title="Map of selected property"
              width="100%" height="100%"
              style={{ border: 0, position: 'absolute', inset: 0 }}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src={embedMapSrc(selected.lat, selected.lng, `${selected.title}, ${selected.neighborhood}, ${selected.city}`)}
            />
          )}
        </div>
        <div className="map-side">
          <div style={{ display: 'flex', gap: 20, marginBottom: 14, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: 12.5, color: 'var(--ink-soft)', display: 'flex', alignItems: 'center', gap: 7 }}>
              <i style={{ width: 9, height: 9, borderRadius: '50%', background: 'var(--teal)', display: 'inline-block' }} /> Property location
            </span>
            {selected && (
              <a href={directionsUrl(selected.lat, selected.lng, `${selected.title}, ${selected.neighborhood}, ${selected.city}`)} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--teal)', fontWeight: 600, fontSize: 12.5, display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                Get Directions →
              </a>
            )}
          </div>
          {selected && (
            <>
              <h3 style={{ fontFamily: "'Fraunces',serif", fontSize: 18, marginBottom: 4 }}>{selected.title}</h3>
              <p style={{ color: 'var(--ink-soft)', fontSize: 13.5, marginBottom: 14 }}>
                {selected.neighborhood}, {selected.city}, {selected.country} · {fmtMoney(selected.priceUSD, currency)}{selected.purpose === 'rent' ? '/mo' : ''}
              </p>
            </>
          )}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 280, overflowY: 'auto', marginBottom: 16 }}>
            {properties.map(p => (
              <button key={p._id} className={`map-list-row${p._id === selectedId ? ' active' : ''}`} onClick={() => setSelectedId(p._id)}>
                <span className="map-list-dot" />
                <span style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 13.5, fontWeight: 600 }}>{p.title}</span>
                  <span style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{p.neighborhood}, {p.city}</span>
                </span>
              </button>
            ))}
          </div>
          <div style={{ background: 'var(--ivory)', borderRadius: 'var(--radius-m)', padding: '18px 20px', fontSize: 13.5, marginTop: 'auto', border: '1px solid var(--stone)' }}>
            Real coordinates for every listing — pulled from public map data for each neighborhood, not placed by hand.
            {selected && (
              <>
                {' '}
                <button style={{ color: 'var(--teal)', fontWeight: 600 }} onClick={() => onOpen(selected._id)}>View full details →</button>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
