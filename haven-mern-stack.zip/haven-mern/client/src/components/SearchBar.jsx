import { useState } from 'react';
import { useApp } from '../context/AppContext';

export default function SearchBar({ onSearch }) {
  const { currency, setCurrency } = useApp();
  const [location, setLocation] = useState('');
  const [purpose, setPurpose] = useState('buy');
  const [beds, setBeds] = useState(0);

  return (
    <div className="wrap" style={{ marginTop: -40, marginBottom: 70, position: 'relative', zIndex: 20 }}>
      <div className="search-bar">
        <div className="search-grid">
          <div className="search-field">
            <label>Where do you want to live?</label>
            <input value={location} onChange={e => setLocation(e.target.value)} placeholder="City, neighborhood or country" />
          </div>
          <div className="search-field">
            <label>Purpose</label>
            <select value={purpose} onChange={e => setPurpose(e.target.value)}>
              <option value="buy">Buy</option>
              <option value="rent">Rent</option>
            </select>
          </div>
          <div className="search-field">
            <label>Bedrooms</label>
            <select value={beds} onChange={e => setBeds(Number(e.target.value))}>
              <option value={0}>Any</option>
              <option value={1}>1+</option>
              <option value={2}>2+</option>
              <option value={3}>3+</option>
              <option value={4}>4+</option>
            </select>
          </div>
          <div className="search-field">
            <label>Currency</label>
            <select value={currency} onChange={e => setCurrency(e.target.value)}>
              {['USD', 'GBP', 'EUR', 'CAD', 'AUD', 'AED', 'SAR', 'PKR', 'INR'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <button className="search-go" onClick={() => onSearch({ purpose, beds: beds || undefined, q: location || undefined })}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
            Search
          </button>
        </div>
      </div>
    </div>
  );
}
