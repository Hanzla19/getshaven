import { useEffect, useState } from 'react';
import { fetchPropertyById } from '../api/properties';
import { fmtMoney } from '../utils/format';
import { useApp } from '../context/AppContext';

export function CompareBar({ onCompare }) {
  const { compareIds, clearCompare } = useApp();
  const [thumbUrls, setThumbUrls] = useState({});

  useEffect(() => {
    compareIds.forEach(id => {
      if (thumbUrls[id]) return;
      fetchPropertyById(id).then(p => setThumbUrls(prev => ({ ...prev, [id]: p.media?.photoUrl }))).catch(() => {});
    });
  }, [compareIds]); // eslint-disable-line react-hooks/exhaustive-deps

  const show = compareIds.length >= 2;

  return (
    <div className={`compare-bar${show ? ' show' : ''}`}>
      <span style={{ fontSize: 13.5 }}>{compareIds.length} properties selected</span>
      <button className="btn btn-gold btn-sm" onClick={onCompare}>Compare</button>
      <button className="icon-btn" style={{ width: 30, height: 30 }} onClick={clearCompare} aria-label="Clear comparison">✕</button>
    </div>
  );
}

export function CompareModal({ propertyIds, onClose }) {
  const { currency } = useApp();
  const [properties, setProperties] = useState([]);

  useEffect(() => {
    if (!propertyIds || !propertyIds.length) return;
    Promise.all(propertyIds.map(fetchPropertyById)).then(setProperties).catch(() => {});
  }, [propertyIds]);

  if (!propertyIds || !propertyIds.length) return null;

  const rows = [
    ['Price', p => fmtMoney(p.priceUSD, currency) + (p.purpose === 'rent' ? '/mo' : '')],
    ['Type', p => p.type],
    ['Bedrooms', p => p.beds],
    ['Bathrooms', p => p.baths],
    ['Size', p => `${p.sizeSqft?.toLocaleString()} sqft`],
    ['Location', p => `${p.city}, ${p.country}`],
    ['Family suitability', p => `${p.hoodScores?.family ?? '—'}%`],
    ['Commute score', p => `${p.hoodScores?.commute ?? '—'}%`],
    ['Amenities score', p => `${p.hoodScores?.amenities ?? '—'}%`],
    ['Affordability score', p => `${p.hoodScores?.afford ?? '—'}%`]
  ];

  const best = properties.length
    ? properties.slice().sort((a, b) => sumScores(b) - sumScores(a))[0]
    : null;

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-card">
        <button className="modal-close" onClick={onClose} aria-label="Close">✕</button>
        <div style={{ padding: 34 }}>
          <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 26, marginBottom: 4 }}>Comparing {properties.length} properties</h2>
          <p style={{ color: 'var(--ink-soft)', fontSize: 14, marginBottom: 22 }}>Scores are AI-calculated indicators based on available data.</p>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th></th>
                  {properties.map(p => <th key={p._id} style={{ padding: '14px 16px', textAlign: 'left', fontSize: 12, textTransform: 'uppercase', color: 'var(--ink-soft)', borderBottom: '1px solid var(--stone)' }}>{p.title}</th>)}
                </tr>
              </thead>
              <tbody>
                {rows.map(([label, fn]) => (
                  <tr key={label}>
                    <td style={{ padding: '14px 16px', color: 'var(--ink-soft)', fontWeight: 500, borderBottom: '1px solid var(--stone)' }}>{label}</td>
                    {properties.map(p => <td key={p._id} style={{ padding: '14px 16px', borderBottom: '1px solid var(--stone)' }}>{fn(p)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {best && (
            <div style={{ background: 'var(--teal)', color: '#fff', borderRadius: 'var(--radius-m)', padding: 22, marginTop: 24, fontSize: 14.5, lineHeight: 1.65 }}>
              <b>AI summary:</b> "{best.title}" in {best.city} looks like the strongest overall match across neighborhood indicators for this comparison. That said, weigh the individual scores above against your own priorities — the highest-scoring option isn't always the cheapest.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function sumScores(p) {
  const s = p.hoodScores || {};
  return (s.family || 0) + (s.commute || 0) + (s.amenities || 0) + (s.afford || 0);
}
