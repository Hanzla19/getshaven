import { useRef, useEffect } from 'react';

export default function Hero() {
  const videoRef = useRef(null);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const reveal = () => v.classList.add('loaded');
    v.addEventListener('playing', reveal);
    const p = v.play();
    if (p && typeof p.catch === 'function') p.catch(() => {}); // autoplay blocked / source unreachable: gradient background stays visible
    return () => v.removeEventListener('playing', reveal);
  }, []);

  return (
    <header className="hero">
      <div className="hero-bg">
        <video
          ref={videoRef}
          muted loop playsInline preload="auto"
          poster="https://images.pexels.com/videos/17224715/architectural-design-architectural-designs-beautiful-home-building-exterior-17224715.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1800"
          aria-hidden="true"
        >
          <source src="https://videos.pexels.com/video-files/17224715/17224715-uhd_2560_1440_30fps.mp4" type="video/mp4" />
        </video>
      </div>
      <div className="hero-inner">
        <div className="hero-eyebrow"><span className="pulse" /> AI-powered global property discovery</div>
        <h1>Find a place that fits your life.</h1>
        <p className="lead">Tell Haven what matters to you — budget, neighborhood, commute, family — and let AI turn it into personalized matches, anywhere in the world.</p>
        <div className="hero-ctas">
          <a href="#finder" className="btn btn-gold">Find My Home</a>
          <a href="#listings" className="btn btn-ghost-light">Explore Properties</a>
          <a href="#sell" className="btn btn-ghost-light">Sell My Property</a>
        </div>
      </div>
    </header>
  );
}
