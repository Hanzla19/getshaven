import { useState, useEffect, useRef } from 'react';
import { svgArt } from '../utils/svgArt';
import { tourRoomsForProperty } from '../utils/roomMedia';
import { directionsUrl } from '../utils/directions';
import { fmtMoney } from '../utils/format';
import { useApp } from '../context/AppContext';

export default function TourExperience({ property, match, onClose }) {
  const { currency } = useApp();
  const [stage, setStage] = useState('black'); // black -> opening -> touring
  const [roomIndex, setRoomIndex] = useState(0);
  const [panel, setPanel] = useState(null); // 'info' | 'budget' | 'finance' | 'hood' | null
  const timers = useRef([]);

  const rooms = property ? tourRoomsForProperty(property) : [];

  useEffect(() => {
    if (!property) return;
    setStage('black');
    setRoomIndex(0);
    setPanel(null);
    timers.current.forEach(clearTimeout);
    timers.current = [
      setTimeout(() => setStage('fading'), 2200),
      setTimeout(() => setStage('opening'), 2500),
      setTimeout(() => setStage('touring'), 4700)
    ];
    return () => timers.current.forEach(clearTimeout);
  }, [property]);

  if (!property) return null;
  const p = property;
  const approachImg = p.media?.photoUrl || svgArt(p.media?.svgArtKey || 'house', p.title, p._id);

  return (
    <div className="tour-overlay">
      <div className="tour-scene" style={{ opacity: 1 }} data-opening={stage === 'opening' || stage === 'touring'}>
        <img
          className={`approach-bg${stage === 'touring' ? ' hide' : ''}`}
          src={approachImg} alt=""
        />
        <div className="door-frame" style={{ display: stage === 'touring' ? 'none' : 'block' }}>
          <div
            className="door-panel left"
            style={{ transform: (stage === 'opening') ? 'rotateY(-108deg)' : 'none' }}
          />
          <div
            className="door-panel right"
            style={{ transform: (stage === 'opening') ? 'rotateY(108deg)' : 'none' }}
          />
        </div>
        <div id="tourRooms">
          {stage === 'touring' && rooms.map((r, i) => (
            <div className={`tour-room${i === roomIndex ? ' active' : ''}`} key={r.key}>
              <RoomMedia room={r} propertyId={p._id} />
            </div>
          ))}
        </div>
      </div>

      <div className={`tour-black${stage !== 'black' ? ' fade' : ''}`}>
        <div className="tour-welcome">WELCOME HOME</div>
        <div className="tour-match-line">{match ? `Your ${match.score}% match` : 'AI Visual Preview'}</div>
      </div>

      <div className="tour-topbar">
        <span style={{ background: 'var(--gold)', color: 'var(--charcoal)', padding: '7px 14px', borderRadius: 100, fontSize: 12.5, fontWeight: 700 }}>
          Interactive Concept Tour
        </span>
        <button className="icon-btn" onClick={onClose} aria-label="Close tour">✕</button>
      </div>

      {stage === 'touring' && (
        <>
          <div className="tour-controls">
            <button className="icon-btn" onClick={() => setPanel('info')} aria-label="Property information">ℹ</button>
            <button className="icon-btn" onClick={() => setPanel('budget')} aria-label="Budget analysis">$</button>
            <button className="icon-btn" onClick={() => setPanel('finance')} aria-label="Financing calculator">%</button>
            <button className="icon-btn" onClick={() => setPanel('hood')} aria-label="Neighborhood">🗺</button>
          </div>
          <div className="tour-caption">
            <div style={{ fontSize: 11, color: 'var(--gold-light)', fontWeight: 700, letterSpacing: '.05em', marginBottom: 6 }}>● AI TOUR GUIDE</div>
            <p style={{ fontSize: 14.5, lineHeight: 1.55 }}>{rooms[roomIndex]?.line}</p>
          </div>
          <div className="tour-room-nav">
            {rooms.map((r, i) => (
              <button key={r.key} className={`tour-room-btn${i === roomIndex ? ' active' : ''}`} onClick={() => setRoomIndex(i)}>
                {r.label}
              </button>
            ))}
          </div>
        </>
      )}

      {panel && (
        <div className="tour-tab-panel">
          <button className="modal-close" style={{ position: 'absolute', top: 16, right: 16, background: 'var(--stone)', color: 'var(--ink)' }} onClick={() => setPanel(null)} aria-label="Close panel">✕</button>
          <TourPanel kind={panel} property={p} currency={currency} />
        </div>
      )}
    </div>
  );
}

function RoomMedia({ room, propertyId }) {
  const base = svgArt(room.svgKey, room.label, propertyId + room.key);
  if (room.video) {
    return (
      <video className="loaded" style={{ width: '100%', height: '100%', objectFit: 'cover' }} muted loop playsInline autoPlay poster={room.video.poster}>
        <source src={room.video.src} type="video/mp4" />
      </video>
    );
  }
  if (room.photo) {
    return <img src={room.photo} alt={room.label} style={{ width: '100%', height: '100%', objectFit: 'cover' }} onError={e => { e.target.src = base; }} />;
  }
  return <img src={base} alt={room.label} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />;
}

function TourPanel({ kind, property: p, currency }) {
  if (kind === 'info') {
    return (
      <>
        <h3 style={{ fontSize: 20, marginBottom: 6 }}>Property information</h3>
        <p style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginBottom: 20 }}>{p.neighborhood}, {p.city}, {p.country}</p>
        <div className="p-price" style={{ fontSize: 24 }}>{fmtMoney(p.priceUSD, currency)}{p.purpose === 'rent' && <span> / month</span>}</div>
        <div className="p-specs" style={{ border: 'none', padding: '10px 0' }}>
          <span><b>{p.beds}</b> bed</span><span><b>{p.baths}</b> bath</span><span><b>{p.sizeSqft?.toLocaleString()}</b> sqft</span>
        </div>
        <p style={{ fontSize: 14, color: 'var(--ink-soft)', lineHeight: 1.6 }}>{p.description}</p>
        <a href={directionsUrl(p.lat, p.lng, `${p.title}, ${p.neighborhood}, ${p.city}`)} target="_blank" rel="noopener noreferrer" className="btn btn-outline btn-sm" style={{ marginTop: 10 }}>
          Get Directions
        </a>
        <p style={{ fontSize: 11.5, color: 'var(--ink-soft)', marginTop: 16, background: 'var(--stone)', padding: '12px 14px', borderRadius: 8, lineHeight: 1.6 }}>
          This is an "Interactive Concept Tour" — an AI-assisted visual preview, not an exact representation of the property.
        </p>
      </>
    );
  }

  if (kind === 'budget') {
    const isBuy = p.purpose === 'buy';
    if (isBuy) {
      const tax = Math.round(p.priceUSD * 0.012 / 12);
      const ins = Math.round(p.priceUSD * 0.005 / 12);
      const maint = Math.round(p.priceUSD * 0.01 / 12);
      const hoa = Math.round((p.hoaMonthlyUSD || 0));
      const total = tax + ins + maint + hoa;
      return (
        <>
          <h3 style={{ fontSize: 20, marginBottom: 6 }}>Budget intelligence</h3>
          <p style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginBottom: 16 }}>Estimated recurring costs — figures are illustrative estimates only.</p>
          <BudgetLine label="Est. property tax / mo" value={fmtMoney(tax, currency)} />
          <BudgetLine label="Est. insurance / mo" value={fmtMoney(ins, currency)} />
          <BudgetLine label="Est. maintenance / mo" value={fmtMoney(maint, currency)} />
          <BudgetLine label="Est. HOA / service charge" value={fmtMoney(hoa, currency)} />
          <BudgetLine label="Est. added monthly cost" value={fmtMoney(total, currency)} bold />
          <p style={{ fontSize: 11.5, color: 'var(--ink-soft)', marginTop: 16, background: 'var(--stone)', padding: '12px 14px', borderRadius: 8, lineHeight: 1.6 }}>
            Estimates only, based on typical local rates. Confirm with local authorities and providers.
          </p>
        </>
      );
    }
    const util = Math.round(p.priceUSD * 0.08);
    const fees = Math.round(p.priceUSD * 0.03);
    return (
      <>
        <h3 style={{ fontSize: 20, marginBottom: 6 }}>Budget intelligence</h3>
        <p style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginBottom: 16 }}>Estimated total monthly housing cost while renting.</p>
        <BudgetLine label="Monthly rent" value={fmtMoney(p.priceUSD, currency)} />
        <BudgetLine label="Est. utilities / mo" value={fmtMoney(util, currency)} />
        <BudgetLine label="Est. one-time fees" value={fmtMoney(fees, currency)} />
        <BudgetLine label="Typical deposit" value={fmtMoney(p.priceUSD, currency)} />
        <BudgetLine label="Est. monthly housing cost" value={fmtMoney(p.priceUSD + util, currency)} bold />
      </>
    );
  }

  if (kind === 'finance') return <FinanceCalculator p={p} currency={currency} />;

  if (kind === 'hood') {
    const scores = p.hoodScores || { family: 70, commute: 70, amenities: 70, afford: 70 };
    return (
      <>
        <h3 style={{ fontSize: 20, marginBottom: 6 }}>Neighborhood intelligence</h3>
        <p style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginBottom: 16 }}>{p.neighborhood}, {p.city} — calculated indicators, not guarantees.</p>
        {Object.entries({ 'Family suitability': scores.family, Commute: scores.commute, Amenities: scores.amenities, Affordability: scores.afford }).map(([k, v]) => (
          <div className="score-row" key={k}>
            <span className="score-label">{k}</span>
            <div className="score-track"><div className="score-fill" style={{ width: `${v}%` }} /></div>
            <span className="score-val">{v}%</span>
          </div>
        ))}
      </>
    );
  }

  return null;
}

function BudgetLine({ label, value, bold }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: bold ? 15 : 13.5, fontWeight: bold ? 700 : 400, padding: '9px 0', borderBottom: bold ? 'none' : '1px dashed var(--stone-dark)' }}>
      <span>{label}</span><span>{value}</span>
    </div>
  );
}

function FinanceCalculator({ p, currency }) {
  const [dp, setDp] = useState(20);
  const [rate, setRate] = useState(6);
  const [term, setTerm] = useState(25);

  const principal = p.priceUSD * (1 - dp / 100);
  const monthlyRate = rate / 100 / 12;
  const n = term * 12;
  const payment = monthlyRate === 0 ? principal / n : (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -n));
  const totalInterest = payment * n - principal;

  return (
    <>
      <h3 style={{ fontSize: 20, marginBottom: 6 }}>Financing calculator</h3>
      <p style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginBottom: 16 }}>Adjust the sliders — figures update live. Estimates only.</p>

      <div style={{ marginBottom: 18 }}>
        <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5, fontWeight: 600, marginBottom: 8 }}><span>Down payment</span><span>{dp}%</span></label>
        <input type="range" min={5} max={50} value={dp} onChange={e => setDp(Number(e.target.value))} style={{ width: '100%', accentColor: 'var(--teal)' }} />
      </div>
      <div style={{ marginBottom: 18 }}>
        <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5, fontWeight: 600, marginBottom: 8 }}><span>Interest rate</span><span>{rate.toFixed(1)}%</span></label>
        <input type="range" min={2} max={12} step={0.1} value={rate} onChange={e => setRate(Number(e.target.value))} style={{ width: '100%', accentColor: 'var(--teal)' }} />
      </div>
      <div style={{ marginBottom: 18 }}>
        <label style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13.5, fontWeight: 600, marginBottom: 8 }}><span>Loan term</span><span>{term} years</span></label>
        <input type="range" min={10} max={30} step={5} value={term} onChange={e => setTerm(Number(e.target.value))} style={{ width: '100%', accentColor: 'var(--teal)' }} />
      </div>

      <div style={{ background: 'var(--teal)', color: '#fff', borderRadius: 'var(--radius-m)', padding: 20 }}>
        <div style={{ fontFamily: "'Fraunces',serif", fontSize: 28 }}>{fmtMoney(payment, currency)}<span style={{ fontSize: 14, fontWeight: 400 }}>/mo</span></div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,.7)', marginTop: 8, lineHeight: 1.6 }}>
          Est. financed amount: {fmtMoney(principal, currency)}<br />
          Est. total interest over {term} years: {fmtMoney(totalInterest, currency)}
        </div>
      </div>
      <p style={{ fontSize: 11.5, color: 'var(--ink-soft)', marginTop: 16, background: 'var(--stone)', padding: '12px 14px', borderRadius: 8, lineHeight: 1.6 }}>
        Actual loan terms depend on your lender, eligibility, location, taxes and fees. Illustrative only, not a loan offer.
      </p>
    </>
  );
}
