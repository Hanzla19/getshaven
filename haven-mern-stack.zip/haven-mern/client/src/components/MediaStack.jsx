import { useState } from 'react';
import { svgArt } from '../utils/svgArt';

/**
 * Renders a real photo or video layered on top of a guaranteed-to-render
 * SVG illustration. The illustration is the base layer and is always
 * visible; the real media only fades in once it actually finishes loading
 * (photo) or starts playing (video). If the real media fails, the
 * illustration is simply what's left showing — never a blank box.
 */
export default function MediaStack({ svgKey, label, seed, photoUrl, video, alt }) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const base = svgArt(svgKey, label, seed);

  return (
    <div className="media-stack">
      <img className="base" src={base} alt={alt} />
      {video && !failed && (
        <video
          className={`real${loaded ? ' loaded' : ''}`}
          muted loop playsInline autoPlay preload="auto"
          poster={video.poster}
          onPlaying={() => setLoaded(true)}
          onError={() => setFailed(true)}
        >
          <source src={video.src} type="video/mp4" />
        </video>
      )}
      {!video && photoUrl && !failed && (
        <img
          className={`real${loaded ? ' loaded' : ''}`}
          src={photoUrl}
          alt={alt}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
        />
      )}
    </div>
  );
}
