import { useEffect, useState } from 'react';

export default function Navbar({ onSavedClick }) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`nav${scrolled ? ' scrolled' : ''}`}>
      <div className="nav-logo"><span className="dot" />Haven</div>
      <div className="nav-links">
        <a href="#finder">AI Finder</a>
        <a href="#listings">Properties</a>
        <a href="#map">Map</a>
        <a href="#sell">Sell</a>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <button className="icon-btn" onClick={onSavedClick} aria-label="View saved properties">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" />
          </svg>
        </button>
        <a href="#finder" className="btn btn-gold btn-sm">Find My Home</a>
      </div>
    </nav>
  );
}
