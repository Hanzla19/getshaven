const STEPS = [
  { n: '01', title: 'Describe your life', desc: 'Tell Haven about your budget, family, commute and priorities in plain language.' },
  { n: '02', title: 'AI extracts requirements', desc: 'Haven turns your words into structured criteria you can confirm or edit.' },
  { n: '03', title: 'Personalized matches', desc: 'Every property gets a transparent match score, with a plain-language explanation.' },
  { n: '04', title: 'Walk through, decide', desc: 'Tour, compare budgets, understand the neighborhood, and save what fits.' }
];

export default function HowItWorks() {
  return (
    <section style={{ background: 'var(--stone)' }}>
      <div className="wrap">
        <div className="section-head">
          <span className="section-tag">How it works</span>
          <h2>From a sentence to a shortlist.</h2>
        </div>
        <div className="how-grid">
          {STEPS.map(s => (
            <div className="card-tile" key={s.n}>
              <div style={{ fontFamily: "'Fraunces',serif", fontSize: 32, color: 'var(--gold)', marginBottom: 12 }}>{s.n}</div>
              <h4 style={{ fontSize: 16, marginBottom: 8 }}>{s.title}</h4>
              <p style={{ fontSize: 13.5, color: 'var(--ink-soft)' }}>{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
