import { useApp } from '../context/AppContext';
import { fmtMoney } from '../utils/format';
import MediaStack from './MediaStack';

export default function PropertyCard({ property, score, onOpen }) {
  const { currency, savedIds, toggleSaved, compareIds, toggleCompare } = useApp();
  const p = property;
  const isSaved = savedIds.has(p._id);
  const isCompared = compareIds.includes(p._id);
  const m = p.media || {};

  return (
    <article className="p-card" role="button" tabIndex={0} onClick={() => onOpen(p._id)} onKeyDown={e => e.key === 'Enter' && onOpen(p._id)}>
      <div className="p-media">
        <MediaStack
          svgKey={m.svgArtKey || 'house'}
          label={p.title}
          seed={p._id}
          photoUrl={m.photoUrl}
          video={m.videoUrl ? { src: m.videoUrl, poster: m.videoPoster } : null}
          alt={p.title}
        />
        <span className="p-badge">{p.purpose === 'rent' ? 'For rent' : 'For sale'}</span>
        <span className="p-demo-tag">Illustrative</span>
        {typeof score === 'number' && (
          <span className="p-match">{score}% ✓</span>
        )}
        <button
          className="p-fav"
          aria-label={isSaved ? 'Remove from saved' : 'Save property'}
          onClick={e => { e.stopPropagation(); toggleSaved(p._id); }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill={isSaved ? '#C9483A' : 'none'} stroke={isSaved ? '#C9483A' : '#2B2F2E'} strokeWidth="2">
            <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" />
          </svg>
        </button>
      </div>
      <div className="p-body">
        <div className="p-price">{fmtMoney(p.priceUSD, currency)}{p.purpose === 'rent' && <span> / month</span>}</div>
        <div className="p-title">{p.title} · {p.neighborhood}, {p.city}</div>
        <div className="p-specs">
          <span><b>{p.beds}</b> bed</span><span><b>{p.baths}</b> bath</span><span><b>{p.sizeSqft?.toLocaleString()}</b> sqft</span>
        </div>
        <label className="p-compare-row" onClick={e => e.stopPropagation()}>
          <input type="checkbox" checked={isCompared} onChange={() => toggleCompare(p._id)} /> Add to comparison
        </label>
      </div>
    </article>
  );
}
