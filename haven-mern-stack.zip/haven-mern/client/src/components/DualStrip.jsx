export default function DualStrip() {
  const scores = [
    ['Family suitability', 92], ['Commute', 89], ['Amenities', 95], ['Affordability', 87]
  ];

  return (
    <section style={{ background: 'var(--teal)', color: '#fff' }}>
      <div className="wrap dual-grid">
        <div>
          <span className="section-tag" style={{ color: 'var(--gold-light)' }}>Neighborhood intelligence</span>
          <h3 style={{ fontSize: 26, margin: '16px 0' }}>Understand where you'd actually be living.</h3>
          <p style={{ color: 'rgba(255,255,255,.75)', fontSize: 15, marginBottom: 24, maxWidth: 420 }}>
            Every property includes calculated indicators for family suitability, commute, amenities and affordability — based on available public and listing data, not guarantees.
          </p>
          {scores.map(([label, val]) => (
            <div className="score-row" key={label}>
              <span className="score-label" style={{ color: 'rgba(255,255,255,.85)', width: 140 }}>{label}</span>
              <div className="score-track" style={{ background: 'rgba(255,255,255,.15)' }}><div className="score-fill" style={{ width: `${val}%`, background: 'var(--gold)' }} /></div>
              <span className="score-val" style={{ color: '#fff' }}>{val}%</span>
            </div>
          ))}
        </div>
        <div>
          <span className="section-tag" style={{ color: 'var(--gold-light)' }}>Budget intelligence</span>
          <h3 style={{ fontSize: 26, margin: '16px 0' }}>See the real monthly picture, not just the price.</h3>
          <p style={{ color: 'rgba(255,255,255,.75)', fontSize: 15, marginBottom: 24, maxWidth: 420 }}>
            Haven estimates total cost of ownership or renting — including taxes, fees and maintenance where applicable — clearly labeled as estimates.
          </p>
          <div style={{ background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.16)', borderRadius: 'var(--radius-m)', padding: 26 }}>
            {[['Base price', '$780,000'], ['Est. property tax / year', '$9,360'], ['Est. insurance / year', '$3,900'], ['Est. maintenance / year', '$7,800']].map(([l, v]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, padding: '9px 0', borderBottom: '1px dashed rgba(255,255,255,.15)', color: 'rgba(255,255,255,.8)' }}>
                <span>{l}</span><span>{v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 16, fontWeight: 700, fontSize: 16 }}>
              <span>Est. monthly cost</span><span>$4,610 / mo*</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
