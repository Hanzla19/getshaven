export default function IntentCards({ intent, onSelect }) {
  const cards = [
    { key: 'buy', glyph: '🏠', title: 'Buy', desc: "Find a home you'll love, with AI that explains why each match fits — and where it might not." },
    { key: 'rent', glyph: '🏡', title: 'Rent', desc: 'Find the right place without wasting time — matched to your budget, move-in date, and lifestyle.' },
    { key: 'sell', glyph: '💰', title: 'Sell', desc: 'Understand your property and reach the right buyers with AI-assisted listing guidance.' }
  ];

  return (
    <section className="wrap">
      <div className="section-head">
        <span className="section-tag">Start here</span>
        <h2>What brings you to Haven?</h2>
        <p>Choose a path — the AI experience adapts immediately to what you're trying to do.</p>
      </div>
      <div className="intent-grid">
        {cards.map(c => (
          <div
            key={c.key}
            className={`intent-card${intent === c.key ? ' active' : ''}`}
            onClick={() => c.key === 'sell' ? document.getElementById('sell')?.scrollIntoView({ behavior: 'smooth' }) : onSelect(c.key)}
          >
            <div className="intent-glyph">{c.glyph}</div>
            <h3>{c.title}</h3>
            <p>{c.desc}</p>
            <span style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--teal)' }}>
              {c.key === 'sell' ? 'Start selling' : `Start ${c.key === 'buy' ? 'buying' : 'renting'}`} →
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
