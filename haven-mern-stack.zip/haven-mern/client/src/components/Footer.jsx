export default function Footer({ savedCount, onSavedClick }) {
  return (
    <footer>
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <div style={{ fontFamily: "'Fraunces',serif", fontSize: 20, color: '#fff', marginBottom: 14 }}>Haven</div>
            <p style={{ fontSize: 13.5, maxWidth: 260, color: 'rgba(255,255,255,.55)' }}>AI-powered property discovery for buying, renting and selling anywhere in the world.</p>
          </div>
          <div className="foot-col">
            <h5>My Home Journey</h5>
            <a href="#listings" onClick={onSavedClick}>Saved properties ({savedCount})</a>
            <a href="#map">Map</a>
          </div>
          <div className="foot-col">
            <h5>Platform</h5>
            <a href="#finder">AI Finder</a><a href="#listings">Properties</a><a href="#map">Map</a><a href="#sell">Sell</a>
          </div>
          <div className="foot-col">
            <h5>Company</h5>
            <a href="#">About</a><a href="#">Careers</a><a href="#">Press</a>
          </div>
          <div className="foot-col">
            <h5>Legal</h5>
            <a href="#">Terms</a><a href="#">Privacy policy</a><a href="#">AI disclaimer</a>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid rgba(255,255,255,.1)', paddingTop: 24, fontSize: 12.5, flexWrap: 'wrap', gap: 12 }}>
          <span>© {new Date().getFullYear()} Haven. Demo product for illustration purposes only.</span>
          <span>Built on the MERN stack — MongoDB, Express, React, Node.</span>
        </div>
      </div>
    </footer>
  );
}
