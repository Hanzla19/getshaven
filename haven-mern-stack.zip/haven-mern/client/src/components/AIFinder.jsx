import { useState, useRef, useEffect } from 'react';
import { extractRequirements, matchProperties } from '../api/ai';
import { fmtMoney } from '../utils/format';

const SUGGESTIONS = [
  '2 bedroom apartment in London, rent under £2,800/month, near a tube station',
  '4 bedroom family home in Toronto with a garage and a backyard, budget CAD 1.1M',
  '3 bedroom house in Lahore, DHA, budget around PKR 6.5 crore, near good schools'
];

const CHIP_LABELS = {
  family: 'Family Friendly', quiet: 'Quiet Neighborhood', schools: 'Good Schools',
  commute: 'Short Commute', garage: 'Garage', backyard: 'Backyard', transit: 'Near Transit',
  pets: 'Pet Friendly', furnished: 'Furnished', office: 'Home Office', amenities: 'Amenities'
};

export default function AIFinder({ intent, onMatches }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [pendingReq, setPendingReq] = useState(null);
  const logRef = useRef(null);

  useEffect(() => { logRef.current?.scrollTo(0, logRef.current.scrollHeight); }, [messages, thinking]);

  async function send(text) {
    const trimmed = (text ?? input).trim();
    if (!trimmed) return;
    setMessages(m => [...m, { role: 'user', text: trimmed }]);
    setInput('');
    setThinking(true);
    try {
      const req = await extractRequirements(trimmed, intent);
      setPendingReq(req);
      setMessages(m => [...m, { role: 'ai', type: 'extraction', req }]);
    } catch (err) {
      setMessages(m => [...m, { role: 'ai', type: 'text', text: "I couldn't reach the AI service — is the backend running? (npm run dev in /server)" }]);
    } finally {
      setThinking(false);
    }
  }

  async function confirm() {
    if (!pendingReq) return;
    setThinking(true);
    try {
      const matches = await matchProperties(pendingReq);
      setMessages(m => [...m, { role: 'ai', type: 'text', text: `I found ${matches.length} strong match${matches.length === 1 ? '' : 'es'} based on what you told me. I've highlighted them below, with an honest look at any trade-offs.` }]);
      onMatches(matches, pendingReq);
      document.getElementById('listings')?.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      setMessages(m => [...m, { role: 'ai', type: 'text', text: "Couldn't fetch matches — is the backend running?" }]);
    } finally {
      setThinking(false);
    }
  }

  function chipsFor(req) {
    const chips = [];
    if (req.beds) chips.push(`${req.beds} Bedroom${req.beds > 1 ? 's' : ''}`);
    if (req.budgetUSD) chips.push(`${fmtMoney(req.budgetUSD, req.budgetCur || 'USD')} Budget`);
    if (req.city) chips.push(`📍 ${req.city}`);
    chips.push(req.purpose === 'rent' ? 'Renting' : 'Buying');
    (req.lifestyle || []).forEach(l => chips.push(CHIP_LABELS[l] || l));
    return chips;
  }

  return (
    <section className="finder" id="finder">
      <div className="wrap">
        <div className="section-head on-dark">
          <span className="section-tag">AI Home Finder</span>
          <h2 style={{ color: '#fff' }}>Tell Haven what you're looking for.</h2>
          <p>Skip the filters. Describe your life, and the assistant extracts the requirements for you — currently set to <b style={{ color: '#fff' }}>{intent}</b>.</p>
        </div>
        <div className="finder-shell">
          <div className="chat-log" ref={logRef}>
            {messages.map((m, i) => (
              <div key={i} className={`bubble ${m.role}`}>
                {m.type === 'extraction' ? (
                  <>
                    <p style={{ marginBottom: 10 }}>Here's what I understood:</p>
                    <div className="chip-row">{chipsFor(m.req).map((c, j) => <span className="chip" key={j}>{c}</span>)}</div>
                    <p style={{ margin: '12px 0 4px', fontSize: 14, color: 'rgba(255,255,255,.65)' }}>Did I understand you correctly?</p>
                    <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                      <button className="btn btn-gold btn-sm" onClick={confirm}>Yes, find my matches</button>
                    </div>
                  </>
                ) : m.text}
              </div>
            ))}
            {thinking && <div className="bubble ai"><div className="thinking-dots"><span /><span /><span /></div></div>}
          </div>
          <div className="finder-input-row">
            <input
              className="finder-input"
              placeholder="e.g. 3 bedroom house in Dubai, budget around AED 2 million, quiet family neighborhood near good schools"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
              aria-label="Describe what you're looking for"
            />
            <button className="finder-send" onClick={() => send()} aria-label="Send">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z" /></svg>
            </button>
          </div>
          <div style={{ marginTop: 16 }}>
            {SUGGESTIONS.map((s, i) => (
              <button key={i} className="sugg-pill" onClick={() => send(s)}>{s}</button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
