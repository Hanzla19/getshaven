const TESTIMONIALS = [
  { text: '"I described what I needed in one sentence and had a shortlist in a minute — with honest notes on what wasn\'t perfect."', who: 'Amara O.', role: 'First-time buyer, Toronto', initial: 'A' },
  { text: '"The budget breakdown was the first time a property site showed me the real monthly number, not just the sticker price."', who: 'Rayan K.', role: 'Relocating, Dubai', initial: 'R' },
  { text: '"The tour felt like actually walking into the home before I booked a viewing. Saved me from two wasted trips."', who: 'Sara M.', role: 'Renter, London', initial: 'S' }
];

const TRUST_CARDS = [
  { title: 'Match scores are estimates', body: "Based on your stated preferences and available data — not a promise of the \"best\" or \"right\" home." },
  { title: 'Costs are estimates', body: 'Taxes, fees and financing figures are illustrative. Confirm real terms with lenders and local authorities.' },
  { title: 'Report a listing', body: 'Every property can be flagged for review if something looks inaccurate or fraudulent.' },
  { title: 'Your data, your control', body: 'Manage privacy settings, saved searches and conversation history at any time.' }
];

export function Testimonials() {
  return (
    <section style={{ background: 'var(--charcoal)', color: '#fff' }}>
      <div className="wrap">
        <div className="section-head on-dark">
          <span className="section-tag">What people say</span>
          <h2>Demo feedback from early users.</h2>
        </div>
        <div className="testi-grid">
          {TESTIMONIALS.map(t => (
            <div className="card-tile on-dark" key={t.who}>
              <p style={{ fontSize: 15, color: 'rgba(255,255,255,.82)', marginBottom: 20, lineHeight: 1.6 }}>{t.text}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'var(--gold)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Fraunces',serif", color: 'var(--charcoal)', fontWeight: 600 }}>{t.initial}</div>
                <div><b style={{ display: 'block', fontSize: 14 }}>{t.who}</b><span style={{ fontSize: 12.5, color: 'rgba(255,255,255,.55)' }}>{t.role}</span></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function TrustSection() {
  return (
    <section style={{ background: 'var(--stone)' }}>
      <div className="wrap">
        <div className="section-head">
          <span className="section-tag">Trust &amp; safety</span>
          <h2>AI-assisted. Never a guarantee.</h2>
        </div>
        <div className="trust-grid">
          {TRUST_CARDS.map(c => (
            <div className="card-tile" key={c.title}>
              <h4 style={{ fontSize: 15, marginBottom: 8 }}>{c.title}</h4>
              <p style={{ fontSize: 13, color: 'var(--ink-soft)' }}>{c.body}</p>
            </div>
          ))}
        </div>
        <p style={{ marginTop: 40, fontSize: 12.5, color: 'var(--ink-soft)', borderTop: '1px solid var(--stone-dark)', paddingTop: 26, lineHeight: 1.7 }}>
          This is a demonstration product. Properties marked "Illustrative" are example listings, not real, purchasable units — Haven has no live MLS or listings feed connected in this scaffold.
          Their prices are grounded in real market research for each neighborhood, with a source link on every listing, but the specific unit, address and photos are constructed for demonstration.
          AI match scores, neighborhood indicators, budget estimates and financing calculations are AI-generated approximations — not guarantees of accuracy, value, or investment outcome.
          Always verify pricing, availability and legal details with a licensed professional before making a financial decision.
        </p>
      </div>
    </section>
  );
}

export function FinalCTA() {
  return (
    <section style={{ background: 'linear-gradient(120deg, var(--teal), var(--charcoal))', color: '#fff' }}>
      <div className="wrap">
        <span className="section-tag" style={{ color: 'var(--gold-light)' }}>Search less. Understand more.</span>
        <h2 style={{ fontFamily: "'Fraunces',serif", fontSize: 'clamp(28px,4vw,48px)', margin: '14px 0 18px' }}>
          Most real-estate sites make you search.<br />We help you decide.
        </h2>
        <p style={{ color: 'rgba(255,255,255,.72)', marginBottom: 30 }}>Start a conversation with Haven and see personalized matches in under a minute.</p>
        <a href="#finder" className="btn btn-gold">Find My Home</a>
      </div>
    </section>
  );
}
