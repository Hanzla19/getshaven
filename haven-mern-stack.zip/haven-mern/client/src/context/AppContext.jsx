import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { fetchSaved, saveProperty, unsaveProperty } from '../api/saved';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [currency, setCurrency] = useState('USD');
  const [savedIds, setSavedIds] = useState(new Set());
  const [compareIds, setCompareIds] = useState([]);
  const [toast, setToastMsg] = useState(null);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2600);
  }, []);

  const refreshSaved = useCallback(async () => {
    try {
      const saved = await fetchSaved();
      setSavedIds(new Set(saved.map(s => s.property?._id || s.property)));
    } catch (err) {
      // Backend not reachable yet (e.g. during first-run setup) — fail quietly.
      console.warn('Could not load saved properties:', err.message);
    }
  }, []);

  useEffect(() => { refreshSaved(); }, [refreshSaved]);

  const toggleSaved = useCallback(async (propertyId) => {
    const isSaved = savedIds.has(propertyId);
    try {
      if (isSaved) {
        await unsaveProperty(propertyId);
        setSavedIds(prev => { const next = new Set(prev); next.delete(propertyId); return next; });
        showToast('Removed from saved');
      } else {
        await saveProperty(propertyId);
        setSavedIds(prev => new Set(prev).add(propertyId));
        showToast('Saved to My Home Journey');
      }
    } catch (err) {
      showToast('Could not update saved properties — is the API running?');
    }
  }, [savedIds, showToast]);

  const toggleCompare = useCallback((propertyId) => {
    setCompareIds(prev => {
      if (prev.includes(propertyId)) return prev.filter(id => id !== propertyId);
      if (prev.length >= 3) { showToast('You can compare up to 3 properties'); return prev; }
      return [...prev, propertyId];
    });
  }, [showToast]);

  const clearCompare = useCallback(() => setCompareIds([]), []);

  const value = {
    currency, setCurrency,
    savedIds, toggleSaved,
    compareIds, toggleCompare, clearCompare,
    toast, showToast
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}
