import client from './client';

export async function extractRequirements(message, purpose) {
  const { data } = await client.post('/ai/finder', { message, purpose });
  return data.requirements;
}

export async function matchProperties(requirements) {
  const { data } = await client.post('/ai/match', { requirements });
  return data.matches; // [{ property, score, breakdown, explanation }]
}

export async function generateSellerDraft(payload) {
  const { data } = await client.post('/ai/seller-draft', payload);
  return data; // { headline, description }
}
