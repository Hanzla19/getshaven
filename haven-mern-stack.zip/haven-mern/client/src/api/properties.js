import client from './client';

export async function fetchProperties(params = {}) {
  const { data } = await client.get('/properties', { params });
  return data.properties;
}

export async function fetchPropertyById(id) {
  const { data } = await client.get(`/properties/${id}`);
  return data.property;
}
