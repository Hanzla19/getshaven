import client from './client';

function getGuestId() {
  let id = localStorage.getItem('haven_guest_id');
  if (!id) {
    id = 'guest_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem('haven_guest_id', id);
  }
  return id;
}

export async function fetchSaved() {
  const { data } = await client.get('/saved', { params: { guestId: getGuestId() } });
  return data.saved; // [{ property: {...} }]
}

export async function saveProperty(propertyId) {
  const { data } = await client.post('/saved', { guestId: getGuestId(), property: propertyId });
  return data.saved;
}

export async function unsaveProperty(propertyId) {
  await client.delete(`/saved/${propertyId}`, { params: { guestId: getGuestId() } });
}
