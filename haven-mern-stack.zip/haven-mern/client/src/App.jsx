import { useState, useCallback } from 'react';
import Navbar from './components/Navbar';
import ApiStatusBanner from './components/ApiStatusBanner';
import Hero from './components/Hero';
import IntentCards from './components/IntentCards';
import AIFinder from './components/AIFinder';
import SearchBar from './components/SearchBar';
import PropertyGrid from './components/PropertyGrid';
import HowItWorks from './components/HowItWorks';
import MapPanel from './components/MapPanel';
import DualStrip from './components/DualStrip';
import SellSection from './components/SellSection';
import { Testimonials, TrustSection, FinalCTA } from './components/Testimonials';
import Footer from './components/Footer';
import PropertyModal from './components/PropertyModal';
import TourExperience from './components/TourExperience';
import { CompareBar, CompareModal } from './components/CompareBar';
import Toast from './components/Toast';
import { useApp } from './context/AppContext';
import { fetchPropertyById } from './api/properties';

export default function App() {
  const { savedIds, compareIds } = useApp();

  const [intent, setIntent] = useState('buy');
  const [matches, setMatches] = useState(null); // AI-matched results, or null for plain browse
  const [requirements, setRequirements] = useState(null);
  const [searchParams, setSearchParams] = useState({});

  const [openPropertyId, setOpenPropertyId] = useState(null);
  const [openProperty, setOpenProperty] = useState(null);
  const [tourProperty, setTourProperty] = useState(null);
  const [showCompare, setShowCompare] = useState(false);

  const handleOpen = useCallback(async (id) => {
    setOpenPropertyId(id);
    try {
      const p = await fetchPropertyById(id);
      setOpenProperty(p);
    } catch (err) {
      // Backend not reachable — modal just won't populate; PropertyGrid already
      // surfaces a clearer connection error above the listings.
    }
  }, []);

  const currentMatch = matches?.find(m => m.property._id === openPropertyId);

  return (
    <>
      <ApiStatusBanner />
      <Navbar onSavedClick={() => { setMatches(null); document.getElementById('listings')?.scrollIntoView({ behavior: 'smooth' }); }} />
      <Hero />
      <IntentCards intent={intent} onSelect={setIntent} />
      <AIFinder intent={intent} onMatches={(m, req) => { setMatches(m); setRequirements(req); }} />
      <SearchBar onSearch={(params) => { setMatches(null); setSearchParams(params); document.getElementById('listings')?.scrollIntoView({ behavior: 'smooth' }); }} />
      <PropertyGrid matches={matches} searchParams={searchParams} onOpen={handleOpen} />
      <HowItWorks />
      <MapPanel onOpen={handleOpen} />
      <DualStrip />
      <SellSection />
      <Testimonials />
      <TrustSection />
      <FinalCTA />
      <Footer savedCount={savedIds.size} onSavedClick={(e) => { e.preventDefault(); setMatches(null); }} />

      <CompareBar onCompare={() => setShowCompare(true)} />
      <Toast />

      {openProperty && (
        <PropertyModal
          property={openProperty}
          match={currentMatch}
          requirements={requirements}
          onClose={() => { setOpenPropertyId(null); setOpenProperty(null); }}
          onOpenTour={(p) => setTourProperty(p)}
        />
      )}

      {tourProperty && (
        <TourExperience
          property={tourProperty}
          match={matches?.find(m => m.property._id === tourProperty._id)}
          onClose={() => setTourProperty(null)}
        />
      )}

      {showCompare && (
        <CompareModal propertyIds={compareIds} onClose={() => setShowCompare(false)} />
      )}
    </>
  );
}
