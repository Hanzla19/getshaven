// Same approximate rates as the server (server/utils/currency.js) — kept in
// sync manually for this scaffold. In production, fetch live rates once from
// the API and cache them, rather than duplicating a hardcoded table.
export const FX_RATES = {
  USD: 1, GBP: 0.79, EUR: 0.92, CAD: 1.37, AUD: 1.52,
  AED: 3.67, SAR: 3.75, PKR: 278, INR: 83
};

export const CURRENCY_SYMBOLS = {
  USD: '$', GBP: '£', EUR: '€', CAD: 'CA$', AUD: 'A$',
  AED: 'AED ', SAR: 'SAR ', PKR: 'PKR ', INR: '₹'
};

export function fx(amountUSD, code) {
  return amountUSD * (FX_RATES[code] || 1);
}

export function fmtMoney(amountUSD, code = 'USD') {
  const v = fx(amountUSD, code);
  return `${CURRENCY_SYMBOLS[code] || ''}${Math.round(v).toLocaleString('en-US')}`;
}
