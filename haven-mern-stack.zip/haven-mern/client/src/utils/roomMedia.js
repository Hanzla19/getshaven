// Verified real Pexels video/photo URLs for common room types, reused across
// properties (matching the specific unit's actual rooms isn't possible
// without a real listings feed — see README for how to wire one in).
export const ROOM_VIDEOS = {
  kitchen: { src: 'https://videos.pexels.com/video-files/3773488/3773488-hd_1920_1080_30fps.mp4', poster: 'https://images.pexels.com/videos/3773488/decoration-design-estate-furniture-3773488.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600' },
  bathroom: { src: 'https://videos.pexels.com/video-files/15887134/15887134-uhd_2560_1440_30fps.mp4', poster: 'https://images.pexels.com/videos/15887134/pexels-photo-15887134.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600' },
  bedroom: { src: 'https://videos.pexels.com/video-files/4307518/4307518-hd_1920_1080_30fps.mp4', poster: 'https://images.pexels.com/videos/4307518/house-4307518.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600' },
  living: { src: 'https://videos.pexels.com/video-files/7533207/7533207-uhd_2560_1440_30fps.mp4', poster: 'https://images.pexels.com/videos/7533207/apartment-architecture-chair-comfort-7533207.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600' }
};

export const ROOM_PHOTOS = {
  backyard: 'https://images.pexels.com/photos/7587884/pexels-photo-7587884.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600',
  balcony: 'https://images.pexels.com/photos/7546776/pexels-photo-7546776.jpeg?auto=compress&cs=tinysrgb&h=900&fit=crop&w=1600'
};

/** Builds the ordered list of tour rooms for a property, based on its amenities/beds. */
export function tourRoomsForProperty(p) {
  const base = [
    { key: 'living', label: 'Living Room', svgKey: 'living', video: ROOM_VIDEOS.living, line: "You're now entering the living room. This space is built around natural light and easy everyday living." },
    { key: 'kitchen', label: 'Kitchen', svgKey: 'kitchen', video: ROOM_VIDEOS.kitchen, line: 'This could work well as the heart of the home — open enough for family meals or entertaining.' }
  ];
  const bedrooms = [];
  for (let i = 1; i <= Math.min(p.beds, 4); i++) {
    bedrooms.push({
      key: 'bed' + i, label: 'Bedroom ' + i, svgKey: 'bed', video: ROOM_VIDEOS.bedroom,
      line: i === 1 ? 'The primary bedroom, positioned away from the main living areas for quiet.' : "This space could work well as a children's room, guest room, or quiet office."
    });
  }
  const rooms = [];
  if (p.amenities.includes('garage')) rooms.push({ key: 'garage', label: 'Garage', svgKey: 'garage', line: 'Covered parking, which also gives extra storage space.' });
  rooms.push(...base, ...bedrooms);
  if (p.amenities.includes('office')) rooms.push({ key: 'office', label: 'Home Office', svgKey: 'office', line: 'A dedicated home office — useful if remote or hybrid work matters to you.' });
  rooms.push({ key: 'bath', label: 'Bathroom', svgKey: 'bath', video: ROOM_VIDEOS.bathroom, line: 'A recently-styled bathroom with good natural light where available.' });
  const outdoorIsBackyard = p.amenities.includes('backyard');
  rooms.push({
    key: 'outdoor', label: outdoorIsBackyard ? 'Backyard' : 'Balcony', svgKey: outdoorIsBackyard ? 'tree' : 'balcony',
    photo: outdoorIsBackyard ? ROOM_PHOTOS.backyard : ROOM_PHOTOS.balcony,
    line: 'The outdoor space — a nice place to unwind, based on the listing photos.'
  });
  return rooms;
}
