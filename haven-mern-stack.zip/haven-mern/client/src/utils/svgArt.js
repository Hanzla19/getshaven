/**
 * Generates a self-contained SVG illustration (as a data URI) for a given
 * room/property type. Used as the guaranteed-to-render base layer behind
 * any real photo/video — if the real media can't load, this stays visible
 * instead of a blank box.
 */
function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) { h = (h << 5) - h + s.charCodeAt(i); h |= 0; }
  return Math.abs(h);
}

const PALETTES = [
  ['#1E4A44', '#2E6B62'],
  ['#8C6A26', '#B98F3D'],
  ['#33413D', '#5C6F68'],
  ['#5B4A2E', '#8A7452'],
  ['#2B3A44', '#41586A'],
  ['#4A3B2E', '#725C44']
];

const ICONS = {
  villa: '<path d="M110,152 L200,86 L290,152" /><rect x="128" y="152" width="144" height="90" /><rect x="182" y="194" width="36" height="48" /><rect x="146" y="170" width="24" height="20" /><rect x="230" y="170" width="24" height="20" />',
  house: '<path d="M124,158 L200,100 L276,158" /><rect x="138" y="158" width="124" height="82" /><rect x="186" y="196" width="28" height="44" /><rect x="152" y="176" width="20" height="18" /><rect x="228" y="176" width="20" height="18" />',
  apartment: '<rect x="150" y="66" width="100" height="176" /><rect x="168" y="90" width="16" height="16" /><rect x="196" y="90" width="16" height="16" /><rect x="224" y="90" width="16" height="16" /><rect x="168" y="122" width="16" height="16" /><rect x="196" y="122" width="16" height="16" /><rect x="224" y="122" width="16" height="16" /><rect x="168" y="154" width="16" height="16" /><rect x="196" y="154" width="16" height="16" /><rect x="224" y="154" width="16" height="16" /><rect x="188" y="202" width="24" height="40" />',
  living: '<rect x="112" y="166" width="176" height="52" rx="10" /><rect x="100" y="150" width="26" height="60" rx="8" /><rect x="274" y="150" width="26" height="60" rx="8" /><path d="M132,166 v-14 h136 v14" />',
  kitchen: '<rect x="120" y="150" width="160" height="16" /><circle cx="160" cy="182" r="14" /><circle cx="210" cy="182" r="14" /><circle cx="160" cy="220" r="14" /><circle cx="210" cy="220" r="14" /><rect x="120" y="150" width="160" height="98" fill="none" />',
  bed: '<rect x="110" y="176" width="180" height="54" rx="8" /><rect x="110" y="152" width="180" height="30" rx="10" /><rect x="122" y="158" width="46" height="18" rx="6" /><rect x="232" y="158" width="46" height="18" rx="6" />',
  bath: '<path d="M112,190 h176 v18 a28,28 0 0 1 -28,28 h-120 a28,28 0 0 1 -28,-28 z" /><path d="M136,190 v-14 a10,10 0 0 1 20,0" /><rect x="240" y="150" width="10" height="26" /><path d="M225,150 h30" />',
  office: '<rect x="140" y="110" width="120" height="80" rx="6" /><rect x="185" y="190" width="30" height="18" /><rect x="160" y="208" width="80" height="10" /><rect x="150" y="228" width="100" height="14" rx="4" />',
  garage: '<path d="M104,196 q0,-34 34,-34 h124 q34,0 34,34 v20 h-192 z" /><circle cx="146" cy="222" r="16" /><circle cx="254" cy="222" r="16" /><path d="M120,178 h160" />',
  tree: '<rect x="192" y="188" width="16" height="54" /><circle cx="170" cy="150" r="34" /><circle cx="210" cy="140" r="38" /><circle cx="238" cy="160" r="28" />',
  balcony: '<path d="M104,150 h192" /><path d="M104,150 v92" /><path d="M296,150 v92" /><path d="M130,150 v92 M156,150 v92 M182,150 v92 M208,150 v92 M234,150 v92 M260,150 v92" /><path d="M104,242 h192" />'
};

export function svgArt(iconKey, label, seed) {
  const key = seed || label || iconKey;
  const idx = hashStr(key) % PALETTES.length;
  const [c1, c2] = PALETTES[idx];
  const angle = 30 + (hashStr(key + 'a') % 90);
  const icon = ICONS[iconKey] || ICONS.house;
  const gid = 'g' + hashStr(key + 'grad');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300">
<defs>
<linearGradient id="${gid}" x1="0%" y1="0%" x2="100%" y2="100%" gradientTransform="rotate(${angle} .5 .5)">
<stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/>
</linearGradient>
<radialGradient id="glow${gid}" cx="28%" cy="18%" r="65%">
<stop offset="0%" stop-color="#ffffff" stop-opacity="0.16"/><stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
</radialGradient>
</defs>
<rect width="400" height="300" fill="url(#${gid})"/>
<rect width="400" height="300" fill="url(#glow${gid})"/>
<rect x="12" y="12" width="376" height="276" fill="none" stroke="rgba(255,255,255,.25)" stroke-width="1.5"/>
<g fill="none" stroke="rgba(255,255,255,.88)" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${icon}</g>
<text x="32" y="264" font-family="Inter, Arial, sans-serif" font-size="13" letter-spacing="2" fill="rgba(255,255,255,.88)" font-weight="600">${label.toUpperCase()}</text>
</svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}
