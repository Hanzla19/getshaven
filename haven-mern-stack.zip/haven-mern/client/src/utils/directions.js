export function isApplePlatform() {
  const ua = navigator.userAgent || '';
  const platform = navigator.platform || '';
  return /iPad|iPhone|iPod/.test(ua) || (platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

export function directionsUrl(lat, lng, label) {
  const dest = `${lat},${lng}`;
  if (isApplePlatform()) {
    return `https://maps.apple.com/?daddr=${dest}&dirflg=d` + (label ? `&q=${encodeURIComponent(label)}` : '');
  }
  return `https://www.google.com/maps/dir/?api=1&destination=${dest}`;
}

export function embedMapSrc(lat, lng, label) {
  return `https://www.google.com/maps?q=${encodeURIComponent(label || '')}+@${lat},${lng}&z=15&output=embed`;
}
