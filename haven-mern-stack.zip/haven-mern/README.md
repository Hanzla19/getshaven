# Haven — AI Real Estate Platform

<p>
  <img alt="Node" src="https://img.shields.io/badge/Node-18%2B-339933?logo=node.js&logoColor=white">
  <img alt="Express" src="https://img.shields.io/badge/Express-4.x-000000?logo=express&logoColor=white">
  <img alt="React" src="https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black">
  <img alt="Vite" src="https://img.shields.io/badge/Vite-5-646CFF?logo=vite&logoColor=white">
  <img alt="MongoDB" src="https://img.shields.io/badge/MongoDB-Atlas%20or%20local-47A248?logo=mongodb&logoColor=white">
  <img alt="License" src="https://img.shields.io/badge/license-MIT-blue">
</p>

**Haven** is an AI-guided real estate platform: describe what you're looking
for in plain language, get a ranked, explained shortlist, walk through a
cinematic room-by-room tour, check the real numbers (budget, financing,
neighborhood scores), and see it all on a real map with real directions.

This is a full **MERN stack** app — MongoDB, Express, React, Node — with a
real API backing the frontend, not a static demo with hardcoded data.

> **Honesty note, upfront:** the specific example properties in this repo are
> illustrative (no live MLS/listings feed is connected), but their pricing is
> grounded in real 2026 market research per neighborhood, their coordinates
> are real, the map is a real embedded Google Map, and the directions links
> are real. See [§ What's real vs. illustrative](#whats-real-vs-illustrative)
> for the full breakdown, and [§ Extending this into production](#extending-this-into-a-production-app)
> for exactly where to plug in a real listings feed or a real LLM.

---

## Contents

- [Features](#features)
- [Tech stack](#tech-stack)
- [Project structure](#project-structure)
- [Quick start](#quick-start)
- [Environment variables](#environment-variables)
- [API reference](#api-reference)
- [Troubleshooting](#troubleshooting)
- [What's real vs. illustrative](#whats-real-vs-illustrative)
- [Extending this into a production app](#extending-this-into-a-production-app)
- [Deployment](#deployment)
- [License](#license)

---

## Features

- 🤖 **AI Home Finder** — conversational search that extracts structured requirements (budget, beds, location, lifestyle) from free text
- 🎯 **Transparent match scoring** — every property gets a scored, explained match ("why this home" + honest "potential concerns"), not a black-box ranking
- 🚪 **Cinematic 3D-style tour** — a door-opening transition into a room-by-room walkthrough, with real video for common rooms and a guaranteed SVG-illustration fallback if real media can't load
- 💰 **Budget & financing intelligence** — recurring-cost breakdowns and a live mortgage calculator
- 🗺️ **Real embedded map + directions** — real coordinates, a real Google Maps embed, and platform-aware directions (Apple Maps on iOS, Google Maps elsewhere)
- ⚖️ **Comparison tool** — compare up to 3 properties side by side with an AI summary
- ❤️ **Saved properties** — persisted to MongoDB, works for guests (no login required) or logged-in users
- 🏷️ **AI seller assistant** — drafts a listing headline/description from only what the seller actually provides
- 🌍 **Multi-currency display** — 9 currencies, formatted client-side
- 🔐 **JWT auth scaffold** — register/login/me routes ready to wire up

## Tech stack

| Layer | Tech |
|---|---|
| Frontend | React 18, Vite 5, plain CSS (no framework) |
| Backend | Node.js, Express 4 |
| Database | MongoDB via Mongoose |
| Auth | JWT (jsonwebtoken + bcryptjs) |
| HTTP client | axios |

## Project structure

```
haven-mern/
├── server/                  Express API + MongoDB
│   ├── config/db.js          Mongoose connection
│   ├── models/                Property, User, SavedProperty
│   ├── controllers/           properties, ai, saved, auth
│   ├── routes/                 one file per resource
│   ├── middleware/             auth (JWT), centralized error handling
│   ├── utils/                  currency conversion, AI match-scoring engine
│   ├── seed/                   10 example properties (real coords + sourced pricing) + seed script
│   └── server.js               entry point
│
├── client/                  React (Vite) frontend
│   └── src/
│       ├── api/                 axios wrappers, one file per resource
│       ├── components/          ~20 components (see below)
│       ├── context/             AppContext — currency, saved ids, compare list, toasts
│       └── utils/                svgArt.js, directions.js, format.js, roomMedia.js
│
├── README.md
├── .gitignore
└── package.json              root convenience scripts (npm run dev runs both)
```

<details>
<summary>Full component list</summary>

`Navbar`, `Hero`, `ApiStatusBanner`, `IntentCards`, `AIFinder`, `SearchBar`,
`PropertyGrid`, `PropertyCard`, `MediaStack`, `PropertyModal`,
`TourExperience`, `MapPanel`, `CompareBar`, `CompareModal`, `HowItWorks`,
`DualStrip`, `SellSection`, `Testimonials`, `TrustSection`, `FinalCTA`,
`Footer`, `Toast`

</details>

## Quick start

```bash
git clone <this-repo-url> haven-mern
cd haven-mern

# 1. install everything (root, server, client)
npm install
npm run install:all

# 2. configure environment
cp server/.env.example server/.env   # then edit MONGO_URI + JWT_SECRET
cp client/.env.example client/.env   # defaults are fine for local dev

# 3. load example data into MongoDB (run once)
npm run seed

# 4. run both server + client together
npm run dev
```

Open **http://localhost:5173**. The API runs on **http://localhost:5000**.

Need MongoDB? The fastest path if you don't want to install it locally is a
free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster — create
one, copy its connection string into `server/.env` as `MONGO_URI`.

## Environment variables

**`server/.env`** (copy from `server/.env.example`)

| Variable | Example | Notes |
|---|---|---|
| `MONGO_URI` | `mongodb://127.0.0.1:27017/haven` | Local Mongo, or an Atlas `mongodb+srv://...` string |
| `PORT` | `5000` | Port the API listens on |
| `CLIENT_URL` | `http://localhost:5173` | Allowed CORS origin(s). Comma-separate for multiple: `https://gethaven.com,https://www.gethaven.com` |
| `JWT_SECRET` | *(long random string)* | Signs login tokens |

**`client/.env`** (copy from `client/.env.example`)

| Variable | Example | Notes |
|---|---|---|
| `VITE_API_URL` | `http://localhost:5000/api` | Must match your API's actual URL/port |

## API reference

| Method | Route | Description |
|---|---|---|
| `GET` | `/api/health` | Health check |
| `GET` | `/api/properties` | List properties. Query: `purpose`, `beds`, `city`, `country`, `q` |
| `GET` | `/api/properties/:id` | Get one property |
| `POST` | `/api/properties` | Create a property |
| `PUT` | `/api/properties/:id` | Update a property |
| `DELETE` | `/api/properties/:id` | Delete a property |
| `POST` | `/api/ai/finder` | `{ message, purpose }` → structured requirements |
| `POST` | `/api/ai/match` | `{ requirements }` → ranked, scored, explained matches |
| `POST` | `/api/ai/seller-draft` | `{ type, beds, features }` → listing headline + description |
| `GET` | `/api/saved?guestId=` | List saved properties |
| `POST` | `/api/saved` | `{ guestId, property }` → save one |
| `DELETE` | `/api/saved/:propertyId?guestId=` | Unsave one |
| `POST` | `/api/auth/register` | `{ name, email, password }` |
| `POST` | `/api/auth/login` | `{ email, password }` |
| `GET` | `/api/auth/me` | Current user — requires `Authorization: Bearer <token>` |

## Troubleshooting

The app shows a **red banner at the top of the page** any time the frontend
can't reach the API — that one banner covers all of the below symptoms at
once, so start there.

| Symptom | Likely cause | Fix |
|---|---|---|
| Red "Backend not reachable" banner | Server isn't running, or crashed on startup | Check the terminal running `npm run dev:server` for errors |
| `MONGO_URI is not set` in the server terminal | `server/.env` doesn't exist yet | `cp server/.env.example server/.env` |
| Server terminal just hangs with no output | `MONGO_URI` points at a MongoDB that isn't reachable | Confirm MongoDB is actually running locally, or that your Atlas connection string, username/password, and [IP allowlist](https://www.mongodb.com/docs/atlas/security-whitelist/) are correct |
| "Could not reach the API" in the AI Finder chat | Same as above — the frontend can't reach `/api/*` | Fix the server first; this resolves itself once the banner disappears |
| Map is blank | Same as above | Same fix — the map now shows its own explicit error message too |
| Properties list is empty but no errors | Server is up, but the database has no data yet | `npm run seed` (from the repo root, or `--prefix server`) |
| CORS error in the browser console | `CLIENT_URL` in `server/.env` doesn't match the URL you're loading the frontend from | Set it to exactly match, e.g. `http://localhost:5173` |

## What's real vs. illustrative

- ✅ **Real** — every property's coordinates; the market pricing (sourced from
  Bayut, Rightmove, Zameen, RentHop, Square Yards, etc. — see the `source`
  link shown on each property); the embedded Google Map; the directions
  links (Apple Maps on iOS, Google Maps elsewhere).
- 🏷️ **Illustrative** — the specific units themselves. There's no live
  MLS/listings feed wired up, so the exact address/photos/videos per card are
  stand-ins, not real for-sale listings. Labeled "Illustrative example" in
  the UI wherever it appears.
- 🔧 **Rule-based, not a live LLM (yet)** — `server/utils/matchScoring.js`'s
  `extractRequirements()` is a small regex parser standing in for a real AI
  call. See below for the upgrade path.

## Extending this into a production app

| Goal | Where to change it |
|---|---|
| **Real LLM** (e.g. Claude) instead of regex parsing | Replace the body of `extractRequirements()` in `server/utils/matchScoring.js` (or call it directly from `server/controllers/aiController.js`) with a call to the Anthropic Messages API, prompting for the same `{ beds, budgetUSD, city, purpose, lifestyle[] }` JSON shape. Nothing downstream needs to change. Same approach for `sellerDraft()`. |
| **Real listings feed** | Replace `server/seed/seedData.js` with a script pulling from a real MLS/IDX API or partner feed, mapped to `server/models/Property.js`. Run it on a schedule instead of as a one-off seed. |
| **Real authentication** | `User`, `authController`, and `middleware/auth.js` already implement JWT register/login/me. `SavedProperty` already supports a logged-in `userId` alongside the guest-id flow — wire up login/register screens and switch `client/src/api/saved.js` to send the JWT. |
| **Real per-unit photos/video** | `Property.media` (`photoUrl`, `videoUrl`, `videoPoster`) already supports per-property real media — point it at real listing photography once you have a real feed. |
| **Live FX rates** | `server/utils/currency.js` and `client/src/utils/format.js` use a hardcoded rate table — swap for a real FX API (e.g. exchangerate.host) and cache it. |

## Deployment

This app is two separate deployables (a static React build + a Node API):

| Piece | Suggested host |
|---|---|
| `client/` (React build) | [Vercel](https://vercel.com) or [Netlify](https://netlify.com) |
| `server/` (Express API) | [Render](https://render.com), [Railway](https://railway.app), or [Fly.io](https://fly.io) |
| Database | [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) (free tier to start) |

1. Create an Atlas cluster, use its connection string as `MONGO_URI`.
2. Deploy `server/`; set `MONGO_URI`, `JWT_SECRET`, and `CLIENT_URL` (your deployed frontend URL) as environment variables on your host.
3. Deploy `client/`; set `VITE_API_URL` (your deployed API URL + `/api`) as an environment variable on your host — **do this in the platform's dashboard**, not just in a local `.env`, since Vite bakes it in at build time.
4. Run `npm run seed` once against the production `MONGO_URI`.
5. If serving both a root domain and `www`, set `CLIENT_URL` to a comma-separated list (`https://example.com,https://www.example.com`) — the server already supports multiple origins.

Both Vercel/Netlify and Render/Railway issue free HTTPS certificates automatically once your domain's DNS points at them.

## License

MIT — see [`LICENSE`](./LICENSE).
