const Property = require('../models/Property');
const { extractRequirements, scoreProperties, explainMatch } = require('../utils/matchScoring');

/**
 * POST /api/ai/finder
 * body: { message: string, purpose?: 'buy'|'rent' }
 * Returns extracted structured requirements the client shows as chips.
 *
 * NOTE: extractRequirements() here is a small rule-based parser standing in
 * for a real LLM call. To use a real model, replace the body of this
 * function with a call to the Anthropic Messages API (or any LLM), prompting
 * it to return the same { beds, budgetUSD, city, purpose, lifestyle[] } JSON
 * shape — nothing else in this file needs to change.
 */
async function finder(req, res, next) {
  try {
    const { message, purpose } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'message is required' });
    }
    const requirements = extractRequirements(message, purpose || 'buy');
    res.json({ requirements });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/ai/match
 * body: { requirements: {...} }  (the object returned by /api/ai/finder,
 *        optionally hand-edited by the user before confirming)
 * Returns properties ranked by fit, each with a score breakdown and a
 * plain-language explanation (why this home / potential concerns).
 */
async function match(req, res, next) {
  try {
    const { requirements } = req.body;
    if (!requirements) return res.status(400).json({ error: 'requirements is required' });

    const properties = await Property.find(requirements.purpose ? { purpose: requirements.purpose } : {});
    const scored = scoreProperties(properties, requirements);

    const matches = scored.map(m => ({
      property: m.property,
      score: m.score,
      breakdown: m.breakdown,
      explanation: explainMatch(m, requirements)
    }));

    res.json({ count: matches.length, matches });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/ai/seller-draft
 * body: { type, beds, features: string[] }
 * Generates a simple listing headline + description from ONLY what the
 * seller provided — never invents features. Stand-in for an LLM call.
 */
async function sellerDraft(req, res, next) {
  try {
    const { type = 'home', beds = 3, features = [] } = req.body;
    const featureLine = features.length ? features.join(', ') : 'well-maintained finishes throughout';
    const headline = `A ${beds}-bedroom ${String(type).toLowerCase()} built for everyday living`;
    const description = `This ${beds}-bedroom ${String(type).toLowerCase()} stands out for its ${featureLine}. Based on the details provided, it should appeal to buyers prioritizing space and everyday comfort. Add photos so the listing can be refined further.`;
    res.json({ headline, description });
  } catch (err) {
    next(err);
  }
}

module.exports = { finder, match, sellerDraft };
