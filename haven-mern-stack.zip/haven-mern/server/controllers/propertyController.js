const Property = require('../models/Property');

// GET /api/properties?purpose=buy&beds=3&city=Dubai&country=UAE&q=villa
async function getProperties(req, res, next) {
  try {
    const { purpose, beds, city, country, q } = req.query;
    const filter = {};
    if (purpose) filter.purpose = purpose;
    if (beds) filter.beds = { $gte: parseInt(beds, 10) };
    if (city) filter.city = new RegExp(city, 'i');
    if (country) filter.country = new RegExp(country, 'i');
    if (q) {
      filter.$or = [
        { title: new RegExp(q, 'i') },
        { city: new RegExp(q, 'i') },
        { country: new RegExp(q, 'i') },
        { neighborhood: new RegExp(q, 'i') }
      ];
    }
    const properties = await Property.find(filter).sort({ createdAt: -1 });
    res.json({ count: properties.length, properties });
  } catch (err) {
    next(err);
  }
}

// GET /api/properties/:id
async function getPropertyById(req, res, next) {
  try {
    const property = await Property.findById(req.params.id);
    if (!property) return res.status(404).json({ error: 'Property not found' });
    res.json({ property });
  } catch (err) {
    next(err);
  }
}

// POST /api/properties  (admin/demo use — no auth gate in this scaffold, add one before production)
async function createProperty(req, res, next) {
  try {
    const property = await Property.create(req.body);
    res.status(201).json({ property });
  } catch (err) {
    next(err);
  }
}

// PUT /api/properties/:id
async function updateProperty(req, res, next) {
  try {
    const property = await Property.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!property) return res.status(404).json({ error: 'Property not found' });
    res.json({ property });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/properties/:id
async function deleteProperty(req, res, next) {
  try {
    const property = await Property.findByIdAndDelete(req.params.id);
    if (!property) return res.status(404).json({ error: 'Property not found' });
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { getProperties, getPropertyById, createProperty, updateProperty, deleteProperty };
