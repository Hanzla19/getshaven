const SavedProperty = require('../models/SavedProperty');

function ownerFilter(req) {
  // req.user is set by the optional auth middleware if a valid JWT was sent.
  if (req.user) return { userId: req.user.id };
  const guestId = req.query.guestId || req.body.guestId;
  if (!guestId) return null;
  return { guestId };
}

// GET /api/saved?guestId=...
async function listSaved(req, res, next) {
  try {
    const owner = ownerFilter(req);
    if (!owner) return res.status(400).json({ error: 'guestId (or auth) is required' });
    const saved = await SavedProperty.find(owner).populate('property');
    res.json({ count: saved.length, saved });
  } catch (err) {
    next(err);
  }
}

// POST /api/saved  { guestId, property }
async function saveProperty(req, res, next) {
  try {
    const owner = ownerFilter(req);
    if (!owner) return res.status(400).json({ error: 'guestId (or auth) is required' });
    const doc = await SavedProperty.findOneAndUpdate(
      { ...owner, property: req.body.property },
      { ...owner, property: req.body.property },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json({ saved: doc });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/saved/:propertyId?guestId=...
async function unsaveProperty(req, res, next) {
  try {
    const owner = ownerFilter(req);
    if (!owner) return res.status(400).json({ error: 'guestId (or auth) is required' });
    await SavedProperty.findOneAndDelete({ ...owner, property: req.params.propertyId });
    res.json({ deleted: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { listSaved, saveProperty, unsaveProperty };
