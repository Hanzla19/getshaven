const mongoose = require('mongoose');

/**
 * Saved / favorited properties.
 * `guestId` lets the demo work without requiring login (the client generates
 * and stores a random guest id in localStorage). If `userId` is present
 * (a logged-in user), that takes precedence.
 */
const SavedPropertySchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    guestId: { type: String, default: null, index: true },
    property: { type: mongoose.Schema.Types.ObjectId, ref: 'Property', required: true }
  },
  { timestamps: true }
);

SavedPropertySchema.index({ guestId: 1, property: 1 }, { unique: true, partialFilterExpression: { guestId: { $type: 'string' } } });
SavedPropertySchema.index({ userId: 1, property: 1 }, { unique: true, partialFilterExpression: { userId: { $type: 'objectId' } } });

module.exports = mongoose.model('SavedProperty', SavedPropertySchema);
