const mongoose = require('mongoose');

const HoodScoresSchema = new mongoose.Schema(
  {
    family: { type: Number, min: 0, max: 100 },
    commute: { type: Number, min: 0, max: 100 },
    amenities: { type: Number, min: 0, max: 100 },
    afford: { type: Number, min: 0, max: 100 }
  },
  { _id: false }
);

const SourceSchema = new mongoose.Schema(
  {
    label: String, // e.g. "Arabian Ranches villa prices — Fidu Properties, 2026"
    url: String
  },
  { _id: false }
);

const MediaSchema = new mongoose.Schema(
  {
    svgArtKey: String, // key used by the client to generate the guaranteed-to-render illustration
    photoUrl: String, // real photo, optional
    videoUrl: String, // real video, optional
    videoPoster: String
  },
  { _id: false }
);

const PropertySchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    type: { type: String, enum: ['House', 'Apartment', 'Villa'], required: true },
    purpose: { type: String, enum: ['buy', 'rent'], required: true, index: true },

    priceUSD: { type: Number, required: true },
    priceNative: { type: Number, required: true },
    currencyNative: { type: String, required: true },

    country: { type: String, required: true, index: true },
    city: { type: String, required: true, index: true },
    neighborhood: { type: String, required: true },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },

    beds: { type: Number, required: true },
    baths: { type: Number, required: true },
    sizeSqft: { type: Number, required: true },

    amenities: [{ type: String }],
    description: { type: String },

    media: MediaSchema,
    hoodScores: HoodScoresSchema,
    hoaMonthlyUSD: { type: Number, default: 0 },

    source: SourceSchema, // link to the real market-data source this price is grounded in

    isDemo: { type: Boolean, default: true } // true = illustrative example, not a live listing
  },
  { timestamps: true }
);

PropertySchema.index({ purpose: 1, beds: 1, city: 1 });

module.exports = mongoose.model('Property', PropertySchema);
