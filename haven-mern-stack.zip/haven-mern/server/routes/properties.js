const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/propertyController');

router.get('/', ctrl.getProperties);
router.get('/:id', ctrl.getPropertyById);
router.post('/', ctrl.createProperty);
router.put('/:id', ctrl.updateProperty);
router.delete('/:id', ctrl.deleteProperty);

module.exports = router;
