const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/savedController');
const { attachUserIfPresent } = require('../middleware/auth');

router.use(attachUserIfPresent);

router.get('/', ctrl.listSaved);
router.post('/', ctrl.saveProperty);
router.delete('/:propertyId', ctrl.unsaveProperty);

module.exports = router;
