const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/aiController');

router.post('/finder', ctrl.finder);
router.post('/match', ctrl.match);
router.post('/seller-draft', ctrl.sellerDraft);

module.exports = router;
