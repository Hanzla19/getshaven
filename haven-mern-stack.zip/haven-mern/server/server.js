require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const propertyRoutes = require('./routes/properties');
const aiRoutes = require('./routes/ai');
const savedRoutes = require('./routes/saved');
const authRoutes = require('./routes/auth');

const app = express();

// CLIENT_URL supports a single origin (https://gethaven.com) or a
// comma-separated list (https://gethaven.com,https://www.gethaven.com)
// so both the root domain and the www subdomain can call the API.
const allowedOrigins = (process.env.CLIENT_URL || '*').split(',').map(s => s.trim());
app.use(cors({
  origin: allowedOrigins.includes('*') ? '*' : allowedOrigins
}));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'haven-api' }));

app.use('/api/properties', propertyRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/saved', savedRoutes);
app.use('/api/auth', authRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

async function start() {
  await connectDB();
  app.listen(PORT, () => console.log(`[server] Haven API running on http://localhost:${PORT}`));
}

start().catch(err => {
  console.error('[server] Failed to start:', err.message);
  process.exit(1);
});

module.exports = app; // exported for testing
