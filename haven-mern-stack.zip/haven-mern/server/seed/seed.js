require('dotenv').config();
const connectDB = require('../config/db');
const Property = require('../models/Property');
const properties = require('./seedData');

async function run() {
  await connectDB();
  console.log(`[seed] Clearing existing properties...`);
  await Property.deleteMany({});
  console.log(`[seed] Inserting ${properties.length} example properties...`);
  await Property.insertMany(properties);
  console.log('[seed] Done.');
  process.exit(0);
}

run().catch(err => {
  console.error('[seed] Failed:', err);
  process.exit(1);
});
