// Centralized error handler — mount this LAST, after all routes.
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  console.error('[error]', err);
  const status = err.status || (err.name === 'ValidationError' ? 400 : 500);
  res.status(status).json({
    error: err.message || 'Something went wrong on the server.',
    ...(process.env.NODE_ENV !== 'production' ? { stack: err.stack } : {})
  });
}

function notFound(req, res) {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
}

module.exports = { errorHandler, notFound };
