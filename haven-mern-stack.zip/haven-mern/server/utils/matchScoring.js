const { FX_RATES } = require('./currency');

/**
 * Very lightweight rule-based "requirement extraction" from free text.
 * This stands in for a real LLM call (e.g. Anthropic's Messages API) — in
 * production, swap extractRequirements() for a prompt to an LLM that returns
 * structured JSON, and keep everything downstream (scoring, explanations)
 * exactly the same.
 */
function extractRequirements(text, defaultPurpose = 'buy') {
  const lower = text.toLowerCase();
  const req = { beds: null, budgetUSD: null, budgetNative: null, budgetCur: null, city: null, country: null, purpose: defaultPurpose, lifestyle: [] };

  const bedsMatch = lower.match(/(\d+)\s*(-|\s)?\s*bed/);
  if (bedsMatch) req.beds = parseInt(bedsMatch[1], 10);

  if (/\brent\b/.test(lower)) req.purpose = 'rent';
  if (/\bbuy\b|\bpurchase\b/.test(lower)) req.purpose = 'buy';

  const curMap = { aed: 'AED', pkr: 'PKR', crore: 'PKR', gbp: 'GBP', eur: 'EUR', cad: 'CAD', aud: 'AUD', sar: 'SAR', inr: 'INR', usd: 'USD', '£': 'GBP', '€': 'EUR', '$': 'USD', '₹': 'INR' };
  const numMatch = lower.match(/(aed|pkr|gbp|eur|cad|aud|sar|inr|usd|£|€|\$)\s*([\d.,]+)\s*(million|m|crore|k|thousand)?/);
  if (numMatch) {
    const cur = curMap[numMatch[1]] || 'USD';
    let val = parseFloat(numMatch[2].replace(/,/g, ''));
    const unit = numMatch[3];
    if (unit === 'million' || unit === 'm') val *= 1000000;
    if (unit === 'crore') val *= 10000000;
    if (unit === 'k' || unit === 'thousand') val *= 1000;
    req.budgetNative = val;
    req.budgetCur = cur;
    req.budgetUSD = val / (FX_RATES[cur] || 1);
  }

  const knownPlaces = [
    ['dubai', 'UAE'], ['london', 'UK'], ['toronto', 'Canada'], ['lahore', 'Pakistan'],
    ['karachi', 'Pakistan'], ['sydney', 'Australia'], ['paris', 'France'],
    ['new york', 'USA'], ['mumbai', 'India']
  ];
  for (const [city, country] of knownPlaces) {
    if (lower.includes(city)) {
      req.city = city.replace(/\b\w/g, c => c.toUpperCase());
      req.country = country;
      break;
    }
  }

  const keywordMap = {
    family: ['family', 'kids', 'children'],
    quiet: ['quiet', 'peaceful'],
    schools: ['school'],
    commute: ['commute', 'close to work', 'near work', 'short commute'],
    garage: ['garage', 'car park', 'parking'],
    backyard: ['backyard', 'garden', 'yard'],
    transit: ['tube', 'metro', 'station', 'transit'],
    pets: ['pet', 'dog', 'cat'],
    furnished: ['furnished'],
    office: ['home office', 'office'],
    amenities: ['gym', 'pool', 'amenities']
  };
  Object.entries(keywordMap).forEach(([tag, words]) => {
    if (words.some(w => lower.includes(w))) req.lifestyle.push(tag);
  });

  return req;
}

const WEIGHTS = { budget: 0.24, bedrooms: 0.18, location: 0.2, purposeMatch: 0.12, lifestyle: 0.14, schools: 0.06, commute: 0.06 };

/**
 * Scores every property against a structured requirements object.
 * Returns [{ property, score, breakdown }], sorted best-first, filtered to
 * a minimum relevance threshold.
 */
function scoreProperties(properties, req) {
  const results = properties.map(p => {
    const breakdown = {};

    if (req.budgetUSD) {
      const diff = Math.abs(p.priceUSD - req.budgetUSD) / req.budgetUSD;
      breakdown.budget = Math.max(35, Math.round(100 - diff * 100));
    } else breakdown.budget = 80;

    if (req.beds) {
      breakdown.bedrooms = p.beds === req.beds ? 100 : p.beds > req.beds ? 88 : Math.max(40, 100 - (req.beds - p.beds) * 22);
    } else breakdown.bedrooms = 85;

    if (req.city) {
      breakdown.location = p.city.toLowerCase() === req.city.toLowerCase() ? 97 : 55;
    } else breakdown.location = 82;

    breakdown.purposeMatch = p.purpose === req.purpose ? 100 : 20;

    if (req.lifestyle && req.lifestyle.length) {
      const overlap = req.lifestyle.filter(l => p.amenities.includes(l)).length;
      breakdown.lifestyle = Math.round(40 + (overlap / req.lifestyle.length) * 60);
    } else breakdown.lifestyle = 84;

    breakdown.schools = req.lifestyle?.includes('schools') ? (p.amenities.includes('schools') ? 95 : 58) : 86;
    breakdown.commute = req.lifestyle?.includes('commute') ? (p.amenities.includes('commute') ? 91 : 62) : 83;

    let score = 0;
    Object.entries(WEIGHTS).forEach(([k, w]) => { score += (breakdown[k] ?? 70) * w; });
    score = Math.round(score);

    return { property: p, score, breakdown };
  });

  return results.filter(r => r.score >= 40).sort((a, b) => b.score - a.score);
}

/** Plain-language "why this home" + honest "potential concerns" for one match. */
function explainMatch(match, req) {
  const parts = [];
  if (req.beds) parts.push(`${req.beds} bedroom${req.beds > 1 ? 's' : ''}`);
  if (req.city) parts.push(`a home in ${req.city}`);
  if (req.lifestyle?.includes('family')) parts.push('a family-friendly setting');
  if (req.lifestyle?.includes('schools')) parts.push('proximity to good schools');
  if (req.lifestyle?.includes('commute')) parts.push('a short commute');
  const priorityStr = parts.length ? parts.join(', ') : 'your stated preferences';

  const lowest = Object.entries(match.breakdown).sort((a, b) => a[1] - b[1])[0];
  let concern = null;
  if (lowest && lowest[1] < 75) {
    const labelMap = {
      budget: 'the price sits a bit outside your target budget',
      bedrooms: 'the bedroom count is slightly off from what you asked for',
      location: 'the location is not an exact match to what you searched for',
      lifestyle: 'not every lifestyle preference is confirmed for this listing',
      schools: 'nearby school quality is not confirmed in this dataset',
      commute: 'commute time during peak hours may run longer than ideal'
    };
    concern = labelMap[lowest[0]] || null;
  }

  return {
    why: `You were looking for ${priorityStr}. This property, "${match.property.title}" in ${match.property.city}, lines up closely with those priorities based on its listed price, size and location.`,
    concern: concern ? `Heads up — ${concern}.` : 'No major concerns detected against your stated priorities — worth a closer look.'
  };
}

module.exports = { extractRequirements, scoreProperties, explainMatch };
