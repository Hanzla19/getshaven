/**
 * Currency helpers.
 * Rates are approximate and for display purposes only — in production,
 * swap FX_RATES for a live rates API (e.g. exchangerate.host, openexchangerates.org).
 */
const FX_RATES = {
  USD: 1,
  GBP: 0.79,
  EUR: 0.92,
  CAD: 1.37,
  AUD: 1.52,
  AED: 3.67,
  SAR: 3.75,
  PKR: 278,
  INR: 83
};

const CURRENCY_SYMBOLS = {
  USD: '$',
  GBP: '£',
  EUR: '€',
  CAD: 'CA$',
  AUD: 'A$',
  AED: 'AED ',
  SAR: 'SAR ',
  PKR: 'PKR ',
  INR: '₹'
};

function convertFromUSD(amountUSD, toCurrency) {
  const rate = FX_RATES[toCurrency] || 1;
  return amountUSD * rate;
}

function formatMoney(amountUSD, currency = 'USD') {
  const converted = convertFromUSD(amountUSD, currency);
  const symbol = CURRENCY_SYMBOLS[currency] || '';
  return `${symbol}${Math.round(converted).toLocaleString('en-US')}`;
}

module.exports = { FX_RATES, CURRENCY_SYMBOLS, convertFromUSD, formatMoney };
